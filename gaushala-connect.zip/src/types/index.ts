export type CowBreed = 'Gir' | 'Sahiwal' | 'Tharparkar' | 'Rathi' | 'Red Sindhi' | 'Kankrej';

export type CowCategory = 
  | 'Milking Cow'
  | 'Dry Cow'
  | 'Pregnant'
  | 'Heifer (Young Female)'
  | 'Calf'
  | 'Elderly / Retired'
  | 'Nandi (Bull)';

export interface Cow {
  id: string;
  tagNumber: string;
  name: string;
  breed: CowBreed;
  gender: 'Female' | 'Male';
  category: CowCategory;
  ageYears: number;
  ageMonths: number;
  weightKg: number;
  lactationCycle: number; // e.g. 2nd lactation
  lactationDay?: number;
  dailyMilkAverageLiters: number;
  photoUrl: string;
  joinedDate: string;
  isAdopted: boolean;
  sponsorName?: string;
  pedigreeMother?: string;
  pedigreeFather?: string;
  notes?: string;
  healthStatus: 'Healthy' | 'Under Observation' | 'Treatment' | 'Quarantine';
}

export type HealthRecordType = 
  | 'Vaccination'
  | 'Deworming'
  | 'Medical Treatment'
  | 'Routine Checkup'
  | 'Ayurvedic Herbals'
  | 'Reproductive Care';

export type HealthSeverity = 'Routine' | 'Mild' | 'Moderate' | 'Critical';

export interface HealthRecord {
  id: string;
  cowId: string;
  cowName: string;
  cowTag: string;
  date: string;
  type: HealthRecordType;
  title: string;
  description: string;
  veterinarian: string;
  severity: HealthSeverity;
  medications?: string;
  dosage?: string;
  nextDueDate?: string;
  recoveryStatus: 'Resolved' | 'Under Treatment' | 'Observation';
}

export interface MilkYield {
  id: string;
  cowId: string;
  cowName: string;
  cowTag: string;
  date: string; // YYYY-MM-DD
  session: 'Morning' | 'Evening';
  yieldLiters: number;
  fatPercentage: number;
  snfPercentage: number;
  temperatureC: number;
  recordedBy: string;
  notes?: string;
}

export type ProductCategory = 
  | 'A2 Dairy'
  | 'Panchagavya & Organic Farming'
  | 'Pooja & Wellness'
  | 'Gau Grass & Seva';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  description: string;
  shortDesc: string;
  price: number;
  unit: string;
  inStockQty: number;
  minStockThreshold: number;
  rating: number;
  reviewsCount: number;
  image: string;
  features: string[];
  vedicBenefits: string;
  shelfLifeDays: number;
  isSubscriptionAvailable?: boolean;
  manufacturingYieldRatio?: string; // e.g., "25L A2 Milk per 1L Ghee"
}

export interface RawMaterial {
  id: string;
  name: string;
  category: 'Feed & Fodder' | 'Packaging' | 'Medicinal Herbs';
  currentStock: number;
  unit: string;
  minThreshold: number;
  costPerUnit: number;
  lastRestocked: string;
}

export interface ManufacturingBatch {
  id: string;
  batchNumber: string;
  date: string;
  sourceMilkLiters: number;
  targetProductId: string;
  targetProductName: string;
  producedUnits: number;
  yieldRatio: string;
  operatorName: string;
  status: 'Completed' | 'In Process' | 'Quality Passed';
  expiryDate: string;
}

export interface InventoryAuditLog {
  id: string;
  timestamp: string;
  productId?: string;
  productName: string;
  changeType: 'Order Deduction' | 'Production Batch' | 'Manual Adjustment' | 'Restock';
  quantityChange: number; // positive or negative
  resultingStock: number;
  referenceId: string; // Order # or Batch #
  notes: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  unit: string;
  image: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  deliveryAddress: string;
  city: string;
  pinCode: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  donationAmount: number;
  totalAmount: number;
  paymentMethod: 'UPI' | 'Card' | 'NetBanking' | 'Cash on Delivery';
  paymentStatus: 'Paid' | 'Pending' | 'Cash on Delivery';
  orderStatus: 'Placed' | 'Processing' | 'Dispatched' | 'Delivered';
  orderDate: string;
  estimatedDelivery: string;
  trackingNotes?: string;
}

export interface MilkSubscription {
  id: string;
  customerName: string;
  phone: string;
  address: string;
  dailyLiters: number;
  frequency: 'Daily' | 'Alternate Days' | 'Weekdays Only';
  deliverySlot: 'Morning (6:00 AM - 7:30 AM)' | 'Evening (5:30 PM - 7:00 PM)';
  startDate: string;
  status: 'Active' | 'Paused' | 'Cancelled';
  monthlyEstimate: number;
}

export interface CowAdoption {
  id: string;
  cowId: string;
  cowName: string;
  cowTag: string;
  cowBreed: string;
  donorName: string;
  donorEmail: string;
  donorPhone: string;
  durationMonths: number;
  monthlyAmount: number;
  totalDonation: number;
  startDate: string;
  certificateId: string;
  message?: string;
}
