import React from 'react';
import { useGaushala, ActiveTab } from '../context/GaushalaContext';
import { ShoppingBag, ChevronRight } from 'lucide-react';

interface NavbarProps {
  onOpenCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenCart }) => {
  const { activeTab, setActiveTab, cart } = useGaushala();

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const navItems: { id: ActiveTab; label: string }[] = [
    { id: 'store', label: 'Storefront' },
    { id: 'cows', label: 'Cows' },
    { id: 'health', label: 'Health' },
    { id: 'yields', label: 'Milk Yields' },
    { id: 'inventory', label: 'Inventory' },
    { id: 'orders', label: 'Orders' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <button
            onClick={() => setActiveTab('store')}
            className="text-left group cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded-sm"
          >
            <span className="text-xl font-bold tracking-tight text-stone-900 group-hover:text-amber-800 transition-colors whitespace-nowrap shrink-0">
              Surabhi Vedic Gaushala
            </span>
          </button>

          {/* Zone 2: Concise single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'text-amber-800 font-semibold'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-700 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenCart}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 active:bg-amber-950 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4 text-amber-200" />
              <span>Cart</span>
              <span className="font-mono-data bg-amber-950/70 text-amber-100 text-xs px-1.5 py-0.5 rounded">
                {totalCartCount}
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Row (responsive overflow scroll) */}
        <div className="flex md:hidden items-center gap-4 py-2 border-t border-stone-100 overflow-x-auto no-scrollbar text-xs font-medium">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`py-1 px-2 whitespace-nowrap shrink-0 transition-colors rounded ${
                  isActive ? 'bg-amber-100 text-amber-900 font-semibold' : 'text-stone-600'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
