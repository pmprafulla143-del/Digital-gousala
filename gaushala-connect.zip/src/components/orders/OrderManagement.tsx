import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { Order } from '../../types';
import { InvoiceModal } from './InvoiceModal';
import { 
  ShoppingBag, 
  FileText, 
  CheckCircle, 
  Truck, 
  Clock, 
  Search,
  IndianRupee,
  ChevronRight
} from 'lucide-react';

export const OrderManagement: React.FC = () => {
  const { orders, updateOrderStatus } = useGaushala();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [viewingInvoiceOrder, setViewingInvoiceOrder] = useState<Order | null>(null);

  const statuses = ['All', 'Placed', 'Processing', 'Dispatched', 'Delivered'];

  // Metrics
  const totalOrders = orders.length;
  const totalRevenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const pendingCount = orders.filter(o => o.orderStatus === 'Placed' || o.orderStatus === 'Processing').length;
  const totalDonations = orders.reduce((sum, o) => sum + (o.donationAmount || 0), 0);

  const filteredOrders = orders.filter((o) => {
    const matchesSearch = 
      o.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customerPhone.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.city.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = selectedStatus === 'All' || o.orderStatus === selectedStatus;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif-brand text-stone-900">
            Customer Orders & Fulfillment
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Tracking online customer orders, dispatch timelines, invoice generation, and Ahimsa dairy fulfillment.
          </p>
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Total Orders Placed</span>
            <ShoppingBag className="w-4 h-4 text-stone-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-stone-900">{totalOrders}</span>
            <span className="text-xs text-stone-400">fulfilled & active</span>
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Pending Fulfillment</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-amber-900">{pendingCount}</span>
            <span className="text-xs text-stone-400">orders to ship</span>
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Storefront Sales Revenue</span>
            <IndianRupee className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-emerald-800">
              ₹{totalRevenue.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Gau Seva Fund Add-on</span>
            <CheckCircle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-stone-900">
              ₹{totalDonations.toLocaleString('en-IN')}
            </span>
            <span className="text-xs text-stone-400">fodder donation</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-stone-200 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by order number (e.g. ORD-8921), customer name, phone, or city..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-900 focus:outline-none focus:ring-1 focus:ring-amber-600"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
          {statuses.map((st) => (
            <button
              key={st}
              onClick={() => setSelectedStatus(st)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                selectedStatus === st
                  ? 'bg-amber-800 text-white font-medium shadow-xs'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-stone-200 p-6">
            <p className="text-xs text-stone-500">No orders match your filter criteria.</p>
          </div>
        ) : (
          filteredOrders.map((order) => (
            <div
              key={order.id}
              className="bg-white rounded-xl border border-stone-200 p-5 hover:border-amber-300 transition-colors space-y-4"
            >
              {/* Order Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-900 border border-amber-200 flex items-center justify-center font-bold text-xs font-mono-data">
                    #{order.orderNumber.split('-')[1]}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-stone-900">
                        {order.orderNumber}
                      </h3>
                      <span className="text-xs text-stone-400">·</span>
                      <span className="text-xs font-mono-data text-stone-500">{order.orderDate}</span>
                    </div>
                    <div className="text-xs text-stone-500">
                      Customer: <strong className="text-stone-800">{order.customerName}</strong> ({order.customerPhone}) · {order.city}
                    </div>
                  </div>
                </div>

                {/* Status Selector & Invoice CTA */}
                <div className="flex items-center gap-2">
                  <select
                    value={order.orderStatus}
                    onChange={(e) => updateOrderStatus(order.id, e.target.value as any)}
                    className="py-1 px-2.5 border border-stone-300 rounded-lg text-xs font-semibold bg-stone-50 text-stone-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="Placed">Placed</option>
                    <option value="Processing">Processing</option>
                    <option value="Dispatched">Dispatched</option>
                    <option value="Delivered">Delivered</option>
                  </select>

                  <button
                    onClick={() => setViewingInvoiceOrder(order)}
                    className="py-1 px-2.5 border border-stone-300 hover:bg-stone-50 rounded-lg text-xs font-medium text-stone-700 flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Invoice</span>
                  </button>
                </div>
              </div>

              {/* Order Items Preview */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <h4 className="font-semibold text-stone-700 mb-2">Itemized Package</h4>
                  <div className="space-y-1.5">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-center text-stone-700">
                        <span>{item.quantity}x {item.productName} ({item.unit})</span>
                        <span className="font-mono-data font-medium text-stone-900">
                          ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                        </span>
                      </div>
                    ))}
                    {order.donationAmount > 0 && (
                      <div className="flex justify-between items-center text-amber-900 pt-1 border-t border-stone-100">
                        <span>Gau Grass Seva Offering:</span>
                        <span className="font-mono-data font-semibold">₹{order.donationAmount}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-stone-50 rounded-lg p-3 space-y-1 text-stone-600 border border-stone-100">
                  <div className="flex justify-between">
                    <span>Payment:</span>
                    <span className="font-semibold text-stone-900">{order.paymentMethod} ({order.paymentStatus})</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Est. Delivery:</span>
                    <span className="font-mono-data font-medium text-stone-800">{order.estimatedDelivery}</span>
                  </div>
                  <div className="flex justify-between text-stone-800 pt-1 border-t border-stone-200 font-bold">
                    <span>Total Paid:</span>
                    <span className="font-mono-data text-amber-900">₹{order.totalAmount.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="text-[11px] text-stone-500 pt-1 truncate">
                    Shipping to: {order.deliveryAddress}, {order.city} - {order.pinCode}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <InvoiceModal
        order={viewingInvoiceOrder}
        onClose={() => setViewingInvoiceOrder(null)}
      />
    </div>
  );
};
