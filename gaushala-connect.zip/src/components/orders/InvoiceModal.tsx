import React from 'react';
import { Order } from '../../types';
import { X, Printer, ShieldCheck } from 'lucide-react';

interface InvoiceModalProps {
  order: Order | null;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ order, onClose }) => {
  if (!order) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="bg-white rounded-xl max-w-2xl w-full p-6 md:p-8 shadow-2xl border border-stone-200 relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-700 rounded-full transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="border border-stone-300 p-6 rounded-lg bg-stone-50 space-y-6 text-xs text-stone-800">
          {/* Invoice Header */}
          <div className="flex justify-between items-start border-b border-stone-200 pb-4">
            <div>
              <div className="text-base font-bold font-serif-brand text-amber-900">
                Surabhi Vedic Gaushala & Dairy Trust
              </div>
              <div className="text-[11px] text-stone-500">Reg. Charitable Ahimsa Trust #VGT-8842-MH</div>
              <div className="text-[11px] text-stone-500">Vedic Dairy Farm & Cow Sanctuary</div>
              <div className="text-[11px] text-stone-500">Support: care@surabhigaushala.org</div>
            </div>

            <div className="text-right">
              <div className="text-sm font-bold uppercase font-mono-data text-stone-900">TAX INVOICE</div>
              <div className="font-mono-data font-semibold text-stone-800">#{order.orderNumber}</div>
              <div className="text-stone-500 text-[11px]">{order.orderDate}</div>
            </div>
          </div>

          {/* Customer & Shipping Details */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="text-stone-400 font-semibold uppercase tracking-wider text-[10px] block mb-1">
                Billed To
              </span>
              <div className="font-bold text-stone-900">{order.customerName}</div>
              <div className="text-stone-600">{order.customerPhone}</div>
              <div className="text-stone-600">{order.customerEmail}</div>
            </div>

            <div>
              <span className="text-stone-400 font-semibold uppercase tracking-wider text-[10px] block mb-1">
                Delivery Destination
              </span>
              <div className="text-stone-700">{order.deliveryAddress}</div>
              <div className="text-stone-700">{order.city} - {order.pinCode}</div>
              <div className="text-stone-500 mt-1">Payment: <strong className="text-stone-800">{order.paymentMethod}</strong> ({order.paymentStatus})</div>
            </div>
          </div>

          {/* Items Table */}
          <div className="border border-stone-200 rounded overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-stone-200/60 text-stone-700 font-semibold">
                <tr>
                  <th className="py-2 px-3">Item Description</th>
                  <th className="py-2 px-3 text-right">Qty</th>
                  <th className="py-2 px-3 text-right">Unit Price</th>
                  <th className="py-2 px-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {order.items.map((item, idx) => (
                  <tr key={idx} className="bg-white">
                    <td className="py-2 px-3">
                      <span className="font-semibold text-stone-900">{item.productName}</span>
                      <span className="text-stone-500 text-[11px] ml-1">({item.unit})</span>
                    </td>
                    <td className="py-2 px-3 text-right font-mono-data">{item.quantity}</td>
                    <td className="py-2 px-3 text-right font-mono-data">₹{item.price.toLocaleString('en-IN')}</td>
                    <td className="py-2 px-3 text-right font-mono-data font-semibold">
                      ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Calculation */}
          <div className="flex justify-end">
            <div className="w-64 space-y-1.5 text-stone-600">
              <div className="flex justify-between">
                <span>Items Subtotal:</span>
                <span className="font-mono-data text-stone-900">₹{order.subtotal.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>Eco Logistics:</span>
                <span className="font-mono-data text-stone-900">
                  {order.deliveryFee === 0 ? 'FREE' : `₹${order.deliveryFee}`}
                </span>
              </div>
              {order.donationAmount > 0 && (
                <div className="flex justify-between text-amber-900">
                  <span>Gau Grass Seva Contribution:</span>
                  <span className="font-mono-data">₹{order.donationAmount}</span>
                </div>
              )}
              <div className="flex justify-between pt-2 border-t border-stone-300 font-bold text-sm text-stone-900">
                <span>Total Amount:</span>
                <span className="font-mono-data">₹{order.totalAmount.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-stone-200 flex items-center justify-between text-stone-500 text-[11px]">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>Certified 100% Ahimsa Vedic Dairy · Non-violent Milking</span>
            </div>
            <span>Authorized Signatory: Surabhi Gaushala</span>
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <button
            onClick={() => window.print()}
            className="flex-1 py-2 px-4 border border-stone-300 hover:bg-stone-100 rounded-lg text-xs font-semibold text-stone-700 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print Invoice</span>
          </button>
          <button
            onClick={onClose}
            className="flex-1 py-2 px-4 bg-amber-800 hover:bg-amber-900 text-white rounded-lg text-xs font-semibold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
