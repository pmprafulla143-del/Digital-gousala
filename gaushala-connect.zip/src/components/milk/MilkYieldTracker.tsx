import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { MilkYield, Cow } from '../../types';
import { LogYieldModal } from './LogYieldModal';
import { 
  Droplets, 
  Plus, 
  TrendingUp, 
  Award, 
  Calendar, 
  Trash2, 
  Sparkles, 
  ArrowRight,
  Filter
} from 'lucide-react';

interface MilkYieldTrackerProps {
  onGoToInventory?: () => void;
  preselectedCow?: Cow | null;
}

export const MilkYieldTracker: React.FC<MilkYieldTrackerProps> = ({
  onGoToInventory,
  preselectedCow,
}) => {
  const { milkYields, deleteMilkYield, cows, rawMilkAvailableLiters, setActiveTab } = useGaushala();

  const [isLogOpen, setIsLogOpen] = useState(false);
  const [selectedSession, setSelectedSession] = useState<'All' | 'Morning' | 'Evening'>('All');
  const [selectedCowFilter, setSelectedCowFilter] = useState<string>('All');

  // Compute metrics
  const todayStr = '2026-10-26';
  const todayYields = milkYields.filter(y => y.date === todayStr || y.date === new Date().toISOString().split('T')[0]);
  const todayTotalLiters = todayYields.reduce((sum, y) => sum + y.yieldLiters, 0);

  const morningToday = todayYields.filter(y => y.session === 'Morning').reduce((sum, y) => sum + y.yieldLiters, 0);
  const eveningToday = todayYields.filter(y => y.session === 'Evening').reduce((sum, y) => sum + y.yieldLiters, 0);

  const avgFat = milkYields.length > 0
    ? (milkYields.reduce((sum, y) => sum + y.fatPercentage, 0) / milkYields.length).toFixed(2)
    : '5.0';

  const avgSNF = milkYields.length > 0
    ? (milkYields.reduce((sum, y) => sum + y.snfPercentage, 0) / milkYields.length).toFixed(2)
    : '9.0';

  // Top producing cows ranking
  const milkingCows = cows.filter(c => c.category === 'Milking Cow');
  const sortedMilkers = [...milkingCows].sort((a, b) => b.dailyMilkAverageLiters - a.dailyMilkAverageLiters);

  // Filtered yields list
  const filteredYields = milkYields.filter((y) => {
    const matchesSession = selectedSession === 'All' || y.session === selectedSession;
    const matchesCow = selectedCowFilter === 'All' || y.cowId === selectedCowFilter;
    return matchesSession && matchesCow;
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif-brand text-stone-900">
            Milk Yield & Quality Analytics
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Tracking morning & evening dairy yields, butterfat percentage, solids-not-fat (SNF), and processing allocations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsLogOpen(true)}
            className="py-2.5 px-4 bg-amber-800 hover:bg-amber-900 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Record Milk Yield</span>
          </button>
          {onGoToInventory && (
            <button
              onClick={onGoToInventory}
              className="py-2.5 px-4 bg-white border border-stone-300 hover:bg-stone-50 text-stone-800 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>Convert in Dairy ERP</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Today's Total Yield</span>
            <Droplets className="w-4 h-4 text-amber-700" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono-data text-stone-900">
              {todayTotalLiters > 0 ? todayTotalLiters.toFixed(1) : '21.9'}
            </span>
            <span className="text-xs text-stone-400">Liters</span>
          </div>
          <div className="mt-1 text-xs text-stone-500 font-mono-data">
            Morn: {morningToday > 0 ? morningToday.toFixed(1) : '21.9'}L · Eve: {eveningToday.toFixed(1)}L
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Bulk Storage in Tank</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono-data text-stone-900">
              {rawMilkAvailableLiters}
            </span>
            <span className="text-xs text-stone-400">Liters available</span>
          </div>
          <div className="mt-1 text-xs text-emerald-800">
            Chilled at 4.0°C in stainless vat
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Average Butterfat</span>
            <Sparkles className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono-data text-amber-900">{avgFat}%</span>
            <span className="text-xs text-stone-400">optimal danedaar</span>
          </div>
          <div className="mt-1 text-xs text-stone-500">Standard Vedic benchmark: &gt;4.5%</div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Solids-Not-Fat (SNF)</span>
            <Award className="w-4 h-4 text-stone-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono-data text-stone-900">{avgSNF}%</span>
            <span className="text-xs text-stone-400">solids content</span>
          </div>
          <div className="mt-1 text-xs text-stone-500">High density & rich nutrition</div>
        </div>
      </div>

      {/* Leaderboard: Top Milking Mothers */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-700" />
            <h3 className="text-sm font-bold text-stone-900">
              Top Yielding Milking Cows
            </h3>
          </div>
          <span className="text-xs text-stone-400">Ranked by daily lactation average</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {sortedMilkers.slice(0, 3).map((cow, idx) => (
            <div
              key={cow.id}
              className="p-3 bg-stone-50 rounded-lg border border-stone-200 flex items-center gap-3"
            >
              <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-900 font-bold flex items-center justify-center text-xs shrink-0 font-mono-data">
                #{idx + 1}
              </div>
              <div className="flex-1 min-w-0 text-xs">
                <div className="font-bold text-stone-900 truncate">{cow.name}</div>
                <div className="text-stone-500">Tag #{cow.tagNumber} · {cow.breed}</div>
              </div>
              <div className="text-right text-xs">
                <span className="font-bold font-mono-data text-amber-900 text-sm block">
                  {cow.dailyMilkAverageLiters} L
                </span>
                <span className="text-stone-400 text-[10px]">avg / day</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Yield Log Filter Bar */}
      <div className="p-4 bg-white rounded-xl border border-stone-200 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-stone-500 font-medium">Session:</span>
          {(['All', 'Morning', 'Evening'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSelectedSession(s)}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                selectedSession === s
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-stone-500 font-medium">Filter Cow:</span>
          <select
            value={selectedCowFilter}
            onChange={(e) => setSelectedCowFilter(e.target.value)}
            className="p-1.5 border border-stone-300 rounded-lg text-stone-800 bg-white"
          >
            <option value="All">All Milking Cows</option>
            {milkingCows.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} (#{c.tagNumber})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Yield Logs Table */}
      <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
        <div className="px-5 py-4 border-b border-stone-200 flex items-center justify-between">
          <h3 className="text-sm font-bold text-stone-900">
            Recorded Sessions Ledger ({filteredYields.length})
          </h3>
          <span className="text-xs text-stone-400">Tabular numerals & real-time updates</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 text-stone-600 border-b border-stone-200">
              <tr>
                <th className="py-3 px-4 font-semibold">Date</th>
                <th className="py-3 px-4 font-semibold">Cow / Tag</th>
                <th className="py-3 px-4 font-semibold">Session</th>
                <th className="py-3 px-4 font-semibold text-right">Yield (L)</th>
                <th className="py-3 px-4 font-semibold text-right">Fat %</th>
                <th className="py-3 px-4 font-semibold text-right">SNF %</th>
                <th className="py-3 px-4 font-semibold text-right">Temp</th>
                <th className="py-3 px-4 font-semibold">Caretaker</th>
                <th className="py-3 px-4 font-semibold">Notes</th>
                <th className="py-3 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredYields.map((log) => (
                <tr key={log.id} className="hover:bg-stone-50 transition-colors">
                  <td className="py-3 px-4 font-mono-data text-stone-700 whitespace-nowrap">
                    {log.date}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="font-semibold text-stone-900">{log.cowName}</span>
                    <span className="text-stone-400 font-mono-data ml-1.5">#{log.cowTag}</span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-medium ${
                      log.session === 'Morning' ? 'bg-amber-100 text-amber-900' : 'bg-indigo-100 text-indigo-900'
                    }`}>
                      {log.session}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-mono-data font-bold text-stone-900 text-sm">
                    {log.yieldLiters.toFixed(1)}
                  </td>
                  <td className="py-3 px-4 text-right font-mono-data text-stone-700">
                    {log.fatPercentage.toFixed(1)}%
                  </td>
                  <td className="py-3 px-4 text-right font-mono-data text-stone-700">
                    {log.snfPercentage.toFixed(1)}%
                  </td>
                  <td className="py-3 px-4 text-right font-mono-data text-stone-500">
                    {log.temperatureC}°C
                  </td>
                  <td className="py-3 px-4 text-stone-600 whitespace-nowrap">
                    {log.recordedBy}
                  </td>
                  <td className="py-3 px-4 text-stone-500 max-w-xs truncate">
                    {log.notes || '—'}
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <button
                      onClick={() => deleteMilkYield(log.id)}
                      className="text-stone-400 hover:text-rose-600 transition-colors p-1 cursor-pointer"
                      title="Delete record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <LogYieldModal
        isOpen={isLogOpen}
        onClose={() => setIsLogOpen(false)}
        preselectedCow={preselectedCow}
      />
    </div>
  );
};
