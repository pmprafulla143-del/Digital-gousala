import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { Cow } from '../../types';
import { X, Droplets } from 'lucide-react';

interface LogYieldModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedCow?: Cow | null;
}

export const LogYieldModal: React.FC<LogYieldModalProps> = ({
  isOpen,
  onClose,
  preselectedCow,
}) => {
  const { cows, addMilkYield } = useGaushala();

  const milkingCows = cows.filter(c => c.category === 'Milking Cow');

  const [cowId, setCowId] = useState(preselectedCow ? preselectedCow.id : milkingCows[0]?.id || '');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [session, setSession] = useState<'Morning' | 'Evening'>('Morning');
  const [yieldLiters, setYieldLiters] = useState(7.5);
  const [fatPercentage, setFatPercentage] = useState(5.1);
  const [snfPercentage, setSnfPercentage] = useState(9.0);
  const [temperatureC, setTemperatureC] = useState(37.1);
  const [recordedBy, setRecordedBy] = useState('Ramesh Caretaker');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cow = cows.find(c => c.id === cowId);
    if (!cow) return;

    addMilkYield({
      cowId: cow.id,
      cowName: cow.name,
      cowTag: cow.tagNumber,
      date,
      session,
      yieldLiters: Number(yieldLiters),
      fatPercentage: Number(fatPercentage),
      snfPercentage: Number(snfPercentage),
      temperatureC: Number(temperatureC),
      recordedBy,
      notes: notes.trim(),
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="bg-white rounded-xl max-w-lg w-full p-6 md:p-8 shadow-2xl border border-stone-200 relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-700 rounded-full transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <div className="flex items-center gap-1.5 text-amber-800 font-semibold mb-1">
              <Droplets className="w-4 h-4" />
              <span>Dairy Yield & Quality Analytics</span>
            </div>
            <h3 className="text-lg font-bold text-stone-900">
              Log Session Milk Yield
            </h3>
            <p className="text-xs text-stone-500">
              Record yield volume and lab quality metrics (Butterfat % & SNF solids).
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Milking Cow *</label>
              <select
                value={cowId}
                onChange={(e) => setCowId(e.target.value)}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                {milkingCows.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} (#{c.tagNumber} · {c.breed})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">Milking Date</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1.5">Milking Session</label>
            <div className="grid grid-cols-2 gap-2">
              {(['Morning', 'Evening'] as const).map((sess) => (
                <button
                  key={sess}
                  type="button"
                  onClick={() => setSession(sess)}
                  className={`py-2 px-3 text-center rounded-lg border font-semibold transition-colors cursor-pointer ${
                    session === sess
                      ? 'bg-amber-800 text-white border-amber-800'
                      : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                  }`}
                >
                  {sess} Session
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Yield (Liters) *</label>
              <input
                type="number"
                step="0.1"
                min="0.5"
                max="30"
                required
                value={yieldLiters}
                onChange={(e) => setYieldLiters(Number(e.target.value))}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">Fat % (Butterfat)</label>
              <input
                type="number"
                step="0.1"
                min="3.0"
                max="8.0"
                value={fatPercentage}
                onChange={(e) => setFatPercentage(Number(e.target.value))}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">SNF % (Solids)</label>
              <input
                type="number"
                step="0.1"
                min="7.0"
                max="11.0"
                value={snfPercentage}
                onChange={(e) => setSnfPercentage(Number(e.target.value))}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Milk Temp (°C)</label>
              <input
                type="number"
                step="0.1"
                value={temperatureC}
                onChange={(e) => setTemperatureC(Number(e.target.value))}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">Recorded By</label>
              <input
                type="text"
                value={recordedBy}
                onChange={(e) => setRecordedBy(e.target.value)}
                placeholder="Caretaker name"
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">Observation Notes</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Rich color, normal letdown, gentle milking"
              className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div className="pt-3 border-t border-stone-200 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-stone-300 hover:bg-stone-100 rounded-lg text-stone-700 font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white rounded-lg font-semibold shadow-sm transition-colors cursor-pointer"
            >
              Save Milk Log
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
