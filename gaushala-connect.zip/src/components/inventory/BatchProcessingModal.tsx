import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { X, Sparkles, AlertCircle, ArrowRight } from 'lucide-react';

interface BatchProcessingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BatchProcessingModal: React.FC<BatchProcessingModalProps> = ({ isOpen, onClose }) => {
  const { products, createManufacturingBatch, rawMilkAvailableLiters } = useGaushala();

  // Dairy products eligible for manufacturing from raw milk
  const dairyProducts = products.filter(p => p.category === 'A2 Dairy');

  const [targetProductId, setTargetProductId] = useState<string>(dairyProducts[0]?.id || 'prod-ghee-500');
  const [sourceMilkLiters, setSourceMilkLiters] = useState<number>(50);
  const [operatorName, setOperatorName] = useState('Mahadev Shastri (Dairy Master)');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const targetProduct = products.find(p => p.id === targetProductId);

  // Auto-calculate expected produced units based on product yield ratios
  let expectedUnits = 1;
  let yieldRatio = '25L Milk = 1L Ghee';
  let defaultShelfLifeDays = 365;

  if (targetProduct) {
    defaultShelfLifeDays = targetProduct.shelfLifeDays;
    if (targetProduct.id === 'prod-ghee-500') {
      // 25L milk produces 1L ghee = 2 jars of 500ml
      // So 50L milk produces 4 jars of 500ml
      expectedUnits = Math.max(1, Math.floor((sourceMilkLiters / 25) * 2));
      yieldRatio = '25L Milk = 1L Bilona Ghee (2 x 500ml jars)';
    } else if (targetProduct.id === 'prod-paneer-500') {
      // 10L milk produces ~1.6kg paneer = ~3 packs of 500g
      expectedUnits = Math.max(1, Math.floor((sourceMilkLiters / 10) * 3));
      yieldRatio = '10L Milk = 1.5kg Paneer (3 x 500g packs)';
    } else if (targetProduct.id === 'prod-milk-1l') {
      expectedUnits = Math.floor(sourceMilkLiters);
      yieldRatio = '1L Milk = 1 Bottled Glass Pack';
    }
  }

  const expiryDate = new Date(Date.now() + defaultShelfLifeDays * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (sourceMilkLiters > rawMilkAvailableLiters) {
      setErrorMsg(`Source milk (${sourceMilkLiters}L) exceeds currently available bulk storage (${rawMilkAvailableLiters}L).`);
      return;
    }

    const result = createManufacturingBatch({
      sourceMilkLiters,
      targetProductId,
      producedUnits: expectedUnits,
      yieldRatio,
      operatorName,
      expiryDate,
    });

    if ('error' in result) {
      setErrorMsg(result.error);
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="bg-white rounded-xl max-w-lg w-full p-6 md:p-8 shadow-2xl border border-stone-200 relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-700 rounded-full transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <div className="flex items-center gap-1.5 text-amber-800 font-semibold mb-1">
              <Sparkles className="w-4 h-4" />
              <span>Automated Dairy Processing ERP</span>
            </div>
            <h3 className="text-lg font-bold text-stone-900">
              New Milk-to-Product Batch Processing
            </h3>
            <p className="text-xs text-stone-500">
              Converts shelter bulk raw milk into finished packaged goods, automatically updating stock and generating an audit trail.
            </p>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="p-3 bg-stone-50 border border-stone-200 rounded-lg flex items-center justify-between">
            <span className="text-stone-600">Available Bulk Milk in Tank:</span>
            <span className="font-mono-data font-bold text-stone-900 text-sm">
              {rawMilkAvailableLiters} Liters
            </span>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">Target Product to Manufacture *</label>
            <select
              value={targetProductId}
              onChange={(e) => setTargetProductId(e.target.value)}
              className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500 font-medium"
            >
              {dairyProducts.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.unit}) — Current Stock: {p.inStockQty}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Raw Milk Allocated (Liters) *</label>
              <input
                type="number"
                min="5"
                max={Math.max(500, rawMilkAvailableLiters)}
                value={sourceMilkLiters}
                onChange={(e) => setSourceMilkLiters(Number(e.target.value))}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data font-semibold focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">Finished Units to Produce</label>
              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-amber-900 font-mono-data font-bold">
                +{expectedUnits} {targetProduct?.unit}
              </div>
            </div>
          </div>

          <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 space-y-1.5 text-stone-600">
            <div className="flex justify-between">
              <span>Conversion Ratio:</span>
              <span className="font-semibold text-stone-800">{yieldRatio}</span>
            </div>
            <div className="flex justify-between">
              <span>Calculated Expiry Date:</span>
              <span className="font-mono-data font-semibold text-stone-800">{expiryDate}</span>
            </div>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">Dairy Supervisor / Master Artisan</label>
            <input
              type="text"
              value={operatorName}
              onChange={(e) => setOperatorName(e.target.value)}
              className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div className="pt-3 border-t border-stone-200 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-stone-300 hover:bg-stone-100 rounded-lg text-stone-700 font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white rounded-lg font-semibold shadow-sm transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>Execute Batch & Update Stock</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
