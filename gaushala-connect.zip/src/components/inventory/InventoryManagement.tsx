import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { Product, RawMaterial } from '../../types';
import { BatchProcessingModal } from './BatchProcessingModal';
import { 
  Package, 
  AlertTriangle, 
  Droplets, 
  Plus, 
  History, 
  Layers, 
  Wheat, 
  Sparkles,
  ArrowDownRight,
  ArrowUpRight,
  CheckCircle,
  RefreshCw
} from 'lucide-react';

export const InventoryManagement: React.FC = () => {
  const { 
    products, 
    rawMaterials, 
    batches, 
    auditLogs, 
    rawMilkAvailableLiters, 
    restockRawMaterial, 
    updateProductStock,
    cows 
  } = useGaushala();

  const [activeSubTab, setActiveSubTab] = useState<'finished' | 'raw' | 'batches' | 'audit'>('finished');
  const [isBatchModalOpen, setIsBatchModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [adjustQty, setAdjustQty] = useState<number>(0);
  const [adjustReason, setAdjustReason] = useState('Physical audit recount');

  // Low stock products
  const lowStockProducts = products.filter(p => p.category !== 'Gau Grass & Seva' && p.inStockQty <= p.minStockThreshold);

  // Fodder consumption calculation:
  // 8 cows * ~25kg green napier = 200kg/day
  const greenGrass = rawMaterials.find(m => m.id === 'raw-1');
  const greenGrassStock = greenGrass?.currentStock || 0;
  const dailyGreenGrassConsumption = cows.length * 25; // 8 * 25 = 200 kg
  const greenGrassDaysRemaining = Math.floor(greenGrassStock / Math.max(1, dailyGreenGrassConsumption));

  const handleOpenAdjust = (prod: Product) => {
    setEditingProduct(prod);
    setAdjustQty(prod.inStockQty);
  };

  const handleSaveAdjust = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    updateProductStock(editingProduct.id, Number(adjustQty), adjustReason);
    setEditingProduct(null);
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif-brand text-stone-900">
            Automated Inventory & Dairy ERP
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Real-time stock ledger, automated customer order deductions, bulk milk manufacturing batch processing, and fodder forecasting.
          </p>
        </div>

        <button
          onClick={() => setIsBatchModalOpen(true)}
          className="self-start md:self-auto py-2.5 px-4 bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors flex items-center gap-2 cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>New Dairy Manufacturing Batch</span>
        </button>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Finished Goods SKUs</span>
            <Package className="w-4 h-4 text-stone-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-stone-900">{products.length}</span>
            <span className="text-xs text-stone-400">catalog items</span>
          </div>
          <div className="mt-1 text-xs text-stone-500">Synced to online storefront</div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Low Stock Alerts</span>
            <AlertTriangle className={`w-4 h-4 ${lowStockProducts.length > 0 ? 'text-rose-600' : 'text-stone-400'}`} />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className={`text-2xl font-bold font-mono-data ${lowStockProducts.length > 0 ? 'text-rose-700' : 'text-stone-900'}`}>
              {lowStockProducts.length}
            </span>
            <span className="text-xs text-stone-400">items below safety</span>
          </div>
          <div className="mt-1 text-xs text-stone-500">
            {lowStockProducts.length > 0 ? 'Requires batch manufacturing' : 'Optimal buffer maintain'}
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Raw Milk in Storage</span>
            <Droplets className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-amber-900">{rawMilkAvailableLiters}</span>
            <span className="text-xs text-stone-400">Liters available</span>
          </div>
          <div className="mt-1 text-xs text-stone-500">Ready for Ghee / Paneer churn</div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Fodder Runway</span>
            <Wheat className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-emerald-800">~{greenGrassDaysRemaining}</span>
            <span className="text-xs text-stone-400">days of green feed</span>
          </div>
          <div className="mt-1 text-xs text-stone-500">{greenGrassStock} kg in shelter silos</div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-1 p-1 bg-stone-200/70 rounded-lg max-w-xl text-xs font-medium">
        <button
          onClick={() => setActiveSubTab('finished')}
          className={`flex-1 py-2 px-3 rounded-md transition-colors cursor-pointer ${
            activeSubTab === 'finished' ? 'bg-white text-stone-900 shadow-xs font-semibold' : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          Finished Products ({products.length})
        </button>
        <button
          onClick={() => setActiveSubTab('raw')}
          className={`flex-1 py-2 px-3 rounded-md transition-colors cursor-pointer ${
            activeSubTab === 'raw' ? 'bg-white text-stone-900 shadow-xs font-semibold' : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          Feed & Raw Materials
        </button>
        <button
          onClick={() => setActiveSubTab('batches')}
          className={`flex-1 py-2 px-3 rounded-md transition-colors cursor-pointer ${
            activeSubTab === 'batches' ? 'bg-white text-stone-900 shadow-xs font-semibold' : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          Production Batches ({batches.length})
        </button>
        <button
          onClick={() => setActiveSubTab('audit')}
          className={`flex-1 py-2 px-3 rounded-md transition-colors cursor-pointer ${
            activeSubTab === 'audit' ? 'bg-white text-stone-900 shadow-xs font-semibold' : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          Audit Ledger ({auditLogs.length})
        </button>
      </div>

      {/* Sub-Tab 1: Finished Goods */}
      {activeSubTab === 'finished' && (
        <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-stone-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-stone-900">
                Packaged Goods & Store Inventory
              </h3>
              <p className="text-xs text-stone-500">
                Automatically deducted whenever customers checkout online.
              </p>
            </div>
            <span className="text-xs text-stone-400">All prices in INR (₹)</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 text-stone-600 border-b border-stone-200">
                <tr>
                  <th className="py-3 px-4 font-semibold">Product Name</th>
                  <th className="py-3 px-4 font-semibold">Category</th>
                  <th className="py-3 px-4 font-semibold text-right">Price</th>
                  <th className="py-3 px-4 font-semibold text-right">Current Stock</th>
                  <th className="py-3 px-4 font-semibold text-right">Min Threshold</th>
                  <th className="py-3 px-4 font-semibold">Stock Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {products.map((prod) => {
                  const isLow = prod.category !== 'Gau Grass & Seva' && prod.inStockQty <= prod.minStockThreshold;
                  return (
                    <tr key={prod.id} className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-semibold text-stone-900">{prod.name}</div>
                        <div className="text-stone-400 text-[11px]">{prod.unit}</div>
                      </td>
                      <td className="py-3 px-4 text-stone-600 whitespace-nowrap">{prod.category}</td>
                      <td className="py-3 px-4 text-right font-mono-data font-semibold text-stone-800">
                        ₹{prod.price.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-data font-bold text-stone-900 text-sm">
                        {prod.category === 'Gau Grass & Seva' ? '∞' : prod.inStockQty}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-data text-stone-500">
                        {prod.category === 'Gau Grass & Seva' ? '—' : prod.minStockThreshold}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {prod.category === 'Gau Grass & Seva' ? (
                          <span className="text-stone-500">Unlimited Seva</span>
                        ) : isLow ? (
                          <span className="inline-flex items-center gap-1 text-rose-700 font-semibold bg-rose-50 px-2 py-0.5 rounded border border-rose-200 text-[11px]">
                            <AlertTriangle className="w-3 h-3" />
                            Low Stock Alert
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[11px]">
                            <CheckCircle className="w-3 h-3" />
                            Optimal
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        {prod.category !== 'Gau Grass & Seva' && (
                          <button
                            onClick={() => handleOpenAdjust(prod)}
                            className="py-1 px-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded text-xs font-medium transition-colors cursor-pointer"
                          >
                            Adjust Stock
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-Tab 2: Raw Materials & Feed */}
      {activeSubTab === 'raw' && (
        <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs space-y-4">
          <div className="px-5 py-4 border-b border-stone-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-stone-900">
                Fodder, Feed & Packaging Supplies
              </h3>
              <p className="text-xs text-stone-500">
                Inventory required for cow nutrition and dairy packaging.
              </p>
            </div>
            <div className="text-xs text-stone-500">
              Herd Feed Rate: <strong className="text-stone-900">~{dailyGreenGrassConsumption} kg green grass / day</strong>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 text-stone-600 border-b border-stone-200">
                <tr>
                  <th className="py-3 px-4 font-semibold">Material Name</th>
                  <th className="py-3 px-4 font-semibold">Category</th>
                  <th className="py-3 px-4 font-semibold text-right">Available Stock</th>
                  <th className="py-3 px-4 font-semibold text-right">Safety Buffer</th>
                  <th className="py-3 px-4 font-semibold text-right">Unit Cost</th>
                  <th className="py-3 px-4 font-semibold">Last Restocked</th>
                  <th className="py-3 px-4 font-semibold text-right">Quick Restock</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {rawMaterials.map((mat) => {
                  const isLow = mat.currentStock <= mat.minThreshold;
                  return (
                    <tr key={mat.id} className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-4 font-semibold text-stone-900 whitespace-nowrap">
                        {mat.name}
                      </td>
                      <td className="py-3 px-4 text-stone-600 whitespace-nowrap">{mat.category}</td>
                      <td className="py-3 px-4 text-right font-mono-data font-bold text-stone-900 text-sm">
                        {mat.currentStock} {mat.unit}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-data text-stone-500">
                        {mat.minThreshold} {mat.unit}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-data text-stone-700">
                        ₹{mat.costPerUnit} / {mat.unit}
                      </td>
                      <td className="py-3 px-4 text-stone-500 font-mono-data">{mat.lastRestocked}</td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={() => restockRawMaterial(mat.id, mat.unit === 'kg' ? 250 : 50)}
                          className="py-1 px-2.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded text-xs font-semibold transition-colors cursor-pointer"
                        >
                          +{mat.unit === 'kg' ? '250 kg' : '50 units'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-Tab 3: Manufacturing Batches */}
      {activeSubTab === 'batches' && (
        <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-stone-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-stone-900">
                Vedic Dairy Manufacturing Batches
              </h3>
              <p className="text-xs text-stone-500">
                Recorded conversion from raw sanctuary milk into A2 Ghee and Paneer.
              </p>
            </div>
            <button
              onClick={() => setIsBatchModalOpen(true)}
              className="py-1.5 px-3 bg-amber-800 hover:bg-amber-900 text-white rounded-lg text-xs font-medium transition-colors cursor-pointer"
            >
              + Create Batch
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 text-stone-600 border-b border-stone-200">
                <tr>
                  <th className="py-3 px-4 font-semibold">Batch #</th>
                  <th className="py-3 px-4 font-semibold">Production Date</th>
                  <th className="py-3 px-4 font-semibold text-right">Raw Milk Used</th>
                  <th className="py-3 px-4 font-semibold">Target Product</th>
                  <th className="py-3 px-4 font-semibold text-right">Yield Generated</th>
                  <th className="py-3 px-4 font-semibold">Yield Ratio</th>
                  <th className="py-3 px-4 font-semibold">Artisan / Operator</th>
                  <th className="py-3 px-4 font-semibold">Best Before</th>
                  <th className="py-3 px-4 font-semibold text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {batches.map((batch) => (
                  <tr key={batch.id} className="hover:bg-stone-50 transition-colors">
                    <td className="py-3 px-4 font-mono-data font-semibold text-stone-900">
                      {batch.batchNumber}
                    </td>
                    <td className="py-3 px-4 font-mono-data text-stone-600">{batch.date}</td>
                    <td className="py-3 px-4 text-right font-mono-data font-bold text-amber-900">
                      {batch.sourceMilkLiters} L
                    </td>
                    <td className="py-3 px-4 font-medium text-stone-900">{batch.targetProductName}</td>
                    <td className="py-3 px-4 text-right font-mono-data font-bold text-emerald-800">
                      +{batch.producedUnits} units
                    </td>
                    <td className="py-3 px-4 text-stone-500">{batch.yieldRatio}</td>
                    <td className="py-3 px-4 text-stone-600">{batch.operatorName}</td>
                    <td className="py-3 px-4 font-mono-data text-stone-500">{batch.expiryDate}</td>
                    <td className="py-3 px-4 text-right">
                      <span className="px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded text-[11px] font-medium">
                        {batch.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-Tab 4: Audit Ledger */}
      {activeSubTab === 'audit' && (
        <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
          <div className="px-5 py-4 border-b border-stone-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-stone-900">
                Automated Inventory Audit Trail
              </h3>
              <p className="text-xs text-stone-500">
                Immutable record of every customer checkout deduction and manufacturing batch addition.
              </p>
            </div>
            <span className="text-xs text-stone-400">Total Logs: {auditLogs.length}</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 text-stone-600 border-b border-stone-200">
                <tr>
                  <th className="py-3 px-4 font-semibold">Timestamp</th>
                  <th className="py-3 px-4 font-semibold">Product</th>
                  <th className="py-3 px-4 font-semibold">Operation Type</th>
                  <th className="py-3 px-4 font-semibold text-right">Qty Delta</th>
                  <th className="py-3 px-4 font-semibold text-right">New Stock Level</th>
                  <th className="py-3 px-4 font-semibold">Reference</th>
                  <th className="py-3 px-4 font-semibold">Details / Trigger</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {auditLogs.map((log) => {
                  const isDeduction = log.quantityChange < 0;
                  return (
                    <tr key={log.id} className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-4 font-mono-data text-stone-500 whitespace-nowrap">
                        {log.timestamp}
                      </td>
                      <td className="py-3 px-4 font-semibold text-stone-900 whitespace-nowrap">
                        {log.productName}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-medium ${
                          log.changeType === 'Order Deduction'
                            ? 'bg-rose-50 text-rose-800 border border-rose-200'
                            : log.changeType === 'Production Batch'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-stone-100 text-stone-800'
                        }`}>
                          {log.changeType}
                        </span>
                      </td>
                      <td className={`py-3 px-4 text-right font-mono-data font-bold text-sm ${
                        isDeduction ? 'text-rose-700' : 'text-emerald-700'
                      }`}>
                        {isDeduction ? log.quantityChange : `+${log.quantityChange}`}
                      </td>
                      <td className="py-3 px-4 text-right font-mono-data font-semibold text-stone-900">
                        {log.resultingStock}
                      </td>
                      <td className="py-3 px-4 font-mono-data text-stone-600">
                        {log.referenceId}
                      </td>
                      <td className="py-3 px-4 text-stone-600 max-w-sm truncate">
                        {log.notes}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Adjust Stock Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-2xl border border-stone-200">
            <h3 className="text-base font-bold text-stone-900">
              Adjust Stock: {editingProduct.name}
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              Current recorded count is {editingProduct.inStockQty} units.
            </p>

            <form onSubmit={handleSaveAdjust} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-medium text-stone-700 mb-1">New Verified Count</label>
                <input
                  type="number"
                  min="0"
                  value={adjustQty}
                  onChange={(e) => setAdjustQty(Number(e.target.value))}
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 font-mono-data font-semibold"
                />
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">Reason for Adjustment</label>
                <input
                  type="text"
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  placeholder="e.g. Physical inventory verification, damaged jar"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900"
                />
              </div>

              <div className="pt-3 border-t border-stone-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-3 py-1.5 border border-stone-300 rounded-lg text-stone-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-amber-800 hover:bg-amber-900 text-white rounded-lg font-semibold cursor-pointer"
                >
                  Save Count
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Batch Processing Modal */}
      <BatchProcessingModal
        isOpen={isBatchModalOpen}
        onClose={() => setIsBatchModalOpen(false)}
      />
    </div>
  );
};
