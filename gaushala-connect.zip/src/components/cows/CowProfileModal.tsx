import React from 'react';
import { Cow, MilkYield, HealthRecord } from '../../types';
import { useGaushala } from '../../context/GaushalaContext';
import { X, Droplets, Stethoscope, Heart, Calendar, ShieldCheck, Plus } from 'lucide-react';

interface CowProfileModalProps {
  cow: Cow | null;
  onClose: () => void;
  onLogYieldForCow?: (cow: Cow) => void;
  onLogHealthForCow?: (cow: Cow) => void;
}

export const CowProfileModal: React.FC<CowProfileModalProps> = ({
  cow,
  onClose,
  onLogYieldForCow,
  onLogHealthForCow,
}) => {
  const { milkYields, healthRecords } = useGaushala();

  if (!cow) return null;

  const cowYields = milkYields.filter(y => y.cowId === cow.id);
  const cowHealth = healthRecords.filter(h => h.cowId === cow.id);

  const totalRecordedMilk = cowYields.reduce((sum, y) => sum + y.yieldLiters, 0);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-stone-400 hover:text-stone-700 rounded-full transition-colors bg-white/80 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Profile Header */}
        <div className="p-6 md:p-8 bg-stone-50 border-b border-stone-200 flex flex-col md:flex-row gap-6 items-start md:items-center">
          <img
            src={cow.photoUrl}
            alt={cow.name}
            referrerPolicy="no-referrer"
            className="w-24 h-24 sm:w-28 sm:h-28 rounded-xl object-cover border border-stone-300 shadow-sm shrink-0"
          />
          <div className="flex-1 space-y-1.5">
            <div className="flex items-center gap-2 text-xs text-stone-500">
              <span className="font-mono-data font-semibold text-stone-800">Tag #{cow.tagNumber}</span>
              <span aria-hidden="true">·</span>
              <span>{cow.breed} Breed</span>
              <span aria-hidden="true">·</span>
              <span>Joined {cow.joinedDate}</span>
            </div>

            <h2 className="text-2xl font-bold font-serif-brand text-stone-900">
              {cow.name}
            </h2>

            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
              <span className="px-2 py-0.5 bg-stone-200/80 text-stone-800 rounded font-medium">
                {cow.category}
              </span>
              <span className={`px-2 py-0.5 rounded font-medium ${
                cow.healthStatus === 'Healthy' 
                  ? 'bg-emerald-100 text-emerald-800' 
                  : 'bg-amber-100 text-amber-800'
              }`}>
                {cow.healthStatus}
              </span>
              {cow.isAdopted ? (
                <span className="px-2 py-0.5 bg-amber-100 text-amber-900 rounded font-medium">
                  Sponsored by {cow.sponsorName}
                </span>
              ) : (
                <span className="px-2 py-0.5 bg-stone-100 text-stone-600 rounded">
                  Seeking Seva Sponsor
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Profile Details Grid */}
        <div className="p-6 md:p-8 space-y-8">
          {/* Key Biological Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 text-xs">
              <span className="text-stone-500 block">Age</span>
              <span className="text-base font-semibold font-mono-data text-stone-900">
                {cow.ageYears}y {cow.ageMonths}m
              </span>
            </div>

            <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 text-xs">
              <span className="text-stone-500 block">Weight</span>
              <span className="text-base font-semibold font-mono-data text-stone-900">
                {cow.weightKg} kg
              </span>
            </div>

            <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 text-xs">
              <span className="text-stone-500 block">Lactation Stage</span>
              <span className="text-base font-semibold font-mono-data text-stone-900">
                {cow.lactationCycle > 0 ? `Cycle #${cow.lactationCycle}` : 'Non-Milking'}
              </span>
            </div>

            <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 text-xs">
              <span className="text-stone-500 block">Daily Milk Average</span>
              <span className="text-base font-semibold font-mono-data text-amber-900">
                {cow.dailyMilkAverageLiters > 0 ? `${cow.dailyMilkAverageLiters} L/day` : 'N/A'}
              </span>
            </div>
          </div>

          {/* Lineage & Notes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-stone-50 rounded-lg border border-stone-200 space-y-2">
              <h4 className="font-semibold text-stone-900">Pedigree & Lineage</h4>
              <div className="space-y-1 text-stone-600">
                <div><span className="text-stone-500">Dam (Mother):</span> {cow.pedigreeMother || 'Sangam Line'}</div>
                <div><span className="text-stone-500">Sire (Father):</span> {cow.pedigreeFather || 'Breeding Nandi'}</div>
                <div><span className="text-stone-500">Breed Classification:</span> Bos indicus (Zebu Humped)</div>
              </div>
            </div>

            <div className="p-4 bg-stone-50 rounded-lg border border-stone-200 space-y-2">
              <h4 className="font-semibold text-stone-900">Temperament & Caretaker Notes</h4>
              <p className="text-stone-600 leading-relaxed">
                {cow.notes || 'Normal routine pasture grazing with mineral lick block.'}
              </p>
            </div>
          </div>

          {/* Milk Yield Records for this Cow */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Droplets className="w-4 h-4 text-amber-700" />
                <h4 className="text-sm font-semibold text-stone-900">
                  Recent Milk Yield Logs ({cowYields.length})
                </h4>
              </div>
              {onLogYieldForCow && cow.category === 'Milking Cow' && (
                <button
                  onClick={() => {
                    onClose();
                    onLogYieldForCow(cow);
                  }}
                  className="text-xs text-amber-800 hover:text-amber-950 font-medium flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Record Yield</span>
                </button>
              )}
            </div>

            {cowYields.length === 0 ? (
              <p className="text-xs text-stone-500 italic p-3 bg-stone-50 rounded-lg">
                No recent milk yields recorded for this cow.
              </p>
            ) : (
              <div className="border border-stone-200 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-stone-100 text-stone-600 border-b border-stone-200">
                    <tr>
                      <th className="py-2 px-3 font-medium">Date</th>
                      <th className="py-2 px-3 font-medium">Session</th>
                      <th className="py-2 px-3 font-medium text-right">Yield</th>
                      <th className="py-2 px-3 font-medium text-right">Fat %</th>
                      <th className="py-2 px-3 font-medium text-right">SNF %</th>
                      <th className="py-2 px-3 font-medium">Recorded By</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {cowYields.map((y) => (
                      <tr key={y.id} className="hover:bg-stone-50">
                        <td className="py-2 px-3 font-mono-data">{y.date}</td>
                        <td className="py-2 px-3 font-medium">{y.session}</td>
                        <td className="py-2 px-3 font-mono-data text-right font-semibold text-amber-900">
                          {y.yieldLiters} L
                        </td>
                        <td className="py-2 px-3 font-mono-data text-right">{y.fatPercentage}%</td>
                        <td className="py-2 px-3 font-mono-data text-right">{y.snfPercentage}%</td>
                        <td className="py-2 px-3 text-stone-500">{y.recordedBy}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Veterinary Health History for this Cow */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-emerald-700" />
                <h4 className="text-sm font-semibold text-stone-900">
                  Veterinary & Health Treatments ({cowHealth.length})
                </h4>
              </div>
              {onLogHealthForCow && (
                <button
                  onClick={() => {
                    onClose();
                    onLogHealthForCow(cow);
                  }}
                  className="text-xs text-amber-800 hover:text-amber-950 font-medium flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log Treatment</span>
                </button>
              )}
            </div>

            {cowHealth.length === 0 ? (
              <p className="text-xs text-stone-500 italic p-3 bg-stone-50 rounded-lg">
                No active medical treatment or ailments recorded for this cow.
              </p>
            ) : (
              <div className="space-y-2">
                {cowHealth.map((h) => (
                  <div
                    key={h.id}
                    className="p-3.5 bg-stone-50 rounded-lg border border-stone-200 text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-stone-900">{h.title}</span>
                        <span className="text-stone-400">·</span>
                        <span className="text-stone-500">{h.type}</span>
                      </div>
                      <span className="font-mono-data text-stone-500">{h.date}</span>
                    </div>

                    <p className="text-stone-600">{h.description}</p>

                    <div className="pt-1 flex flex-wrap items-center gap-4 text-stone-500 border-t border-stone-200/60">
                      <div><strong className="text-stone-700">Attending Vet:</strong> {h.veterinarian}</div>
                      {h.medications && <div><strong className="text-stone-700">Medications:</strong> {h.medications}</div>}
                      {h.nextDueDate && <div><strong className="text-stone-700">Next Booster:</strong> {h.nextDueDate}</div>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
