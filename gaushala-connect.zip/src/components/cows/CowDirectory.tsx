import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { Cow, CowBreed, CowCategory } from '../../types';
import { CowProfileModal } from './CowProfileModal';
import { AddCowModal } from './AddCowModal';
import { AdoptionModal } from '../store/AdoptionModal';
import { 
  Search, 
  Plus, 
  Heart, 
  ShieldCheck, 
  Droplets, 
  ArrowUpRight,
  Filter
} from 'lucide-react';

interface CowDirectoryProps {
  onLogYieldForCow?: (cow: Cow) => void;
  onLogHealthForCow?: (cow: Cow) => void;
}

export const CowDirectory: React.FC<CowDirectoryProps> = ({
  onLogYieldForCow,
  onLogHealthForCow,
}) => {
  const { cows } = useGaushala();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBreed, setSelectedBreed] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedCow, setSelectedCow] = useState<Cow | null>(null);
  const [adoptingCow, setAdoptingCow] = useState<Cow | null>(null);
  const [isAddCowOpen, setIsAddCowOpen] = useState(false);

  const breeds = ['All', 'Gir', 'Sahiwal', 'Tharparkar', 'Rathi'];
  const categories = ['All', 'Milking Cow', 'Dry Cow', 'Pregnant', 'Calf', 'Elderly / Retired', 'Nandi (Bull)'];

  // Metrics
  const totalCows = cows.length;
  const milkingCount = cows.filter(c => c.category === 'Milking Cow').length;
  const pregnantCount = cows.filter(c => c.category === 'Pregnant').length;
  const totalDailyYieldAvg = cows
    .filter(c => c.category === 'Milking Cow')
    .reduce((sum, c) => sum + c.dailyMilkAverageLiters, 0);
  const sponsoredCount = cows.filter(c => c.isAdopted).length;

  const filteredCows = cows.filter((cow) => {
    const matchesSearch = 
      cow.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cow.tagNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (cow.sponsorName && cow.sponsorName.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesBreed = selectedBreed === 'All' || cow.breed === selectedBreed;
    const matchesCategory = selectedCategory === 'All' || cow.category === selectedCategory;

    return matchesSearch && matchesBreed && matchesCategory;
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Herd Summary Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif-brand text-stone-900">
            Gau Parivar & Cow Directory
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Complete registry of all sanctuary cows, life stages, lineage, and daily health metrics.
          </p>
        </div>

        <button
          onClick={() => setIsAddCowOpen(true)}
          className="self-start md:self-auto py-2.5 px-4 bg-amber-800 hover:bg-amber-900 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Register New Cow</span>
        </button>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <span className="text-xs text-stone-500 block">Total Sanctuary Herd</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-stone-900">{totalCows}</span>
            <span className="text-xs text-stone-400">cows & calves</span>
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <span className="text-xs text-stone-500 block">Active Milking Mothers</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-amber-900">{milkingCount}</span>
            <span className="text-xs text-stone-400">indigenous cows</span>
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <span className="text-xs text-stone-500 block">Shelter Milk Output</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-stone-900">~{totalDailyYieldAvg.toFixed(1)}</span>
            <span className="text-xs text-stone-400">Liters / day</span>
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <span className="text-xs text-stone-500 block">Adopted / Sponsored</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-emerald-800">{sponsoredCount}</span>
            <span className="text-xs text-stone-400">of {totalCows} supported</span>
          </div>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="p-4 bg-white rounded-xl border border-stone-200 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by cow name, tag (e.g. GIR-204), or sponsor..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-900 focus:outline-none focus:ring-1 focus:ring-amber-600"
            />
          </div>
        </div>

        {/* Filter Rows */}
        <div className="space-y-2 text-xs">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <span className="text-stone-400 font-medium whitespace-nowrap shrink-0">Breed:</span>
            {breeds.map((b) => (
              <button
                key={b}
                onClick={() => setSelectedBreed(b)}
                className={`px-2.5 py-1 rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  selectedBreed === b
                    ? 'bg-amber-800 text-white font-medium'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                {b}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <span className="text-stone-400 font-medium whitespace-nowrap shrink-0">Lifecycle:</span>
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedCategory(c)}
                className={`px-2.5 py-1 rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  selectedCategory === c
                    ? 'bg-amber-800 text-white font-medium'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Cows Grid */}
      {filteredCows.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl border border-stone-200 p-6 space-y-3">
          <p className="text-sm font-medium text-stone-600">No cows found matching your criteria.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedBreed('All');
              setSelectedCategory('All');
            }}
            className="text-xs text-amber-800 font-semibold underline cursor-pointer"
          >
            Clear filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredCows.map((cow) => (
            <div
              key={cow.id}
              onClick={() => setSelectedCow(cow)}
              className="group bg-white rounded-xl border border-stone-200 overflow-hidden hover:border-amber-400/80 hover:shadow-md transition-all flex flex-col justify-between cursor-pointer"
            >
              <div>
                {/* Photo Header */}
                <div className="relative aspect-4/3 bg-stone-100 overflow-hidden">
                  <img
                    src={cow.photoUrl}
                    alt={cow.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                  />
                  <div className="absolute top-2.5 left-2.5 bg-black/70 text-white text-[11px] font-mono-data px-2 py-0.5 rounded backdrop-blur-xs">
                    #{cow.tagNumber}
                  </div>
                  <div className={`absolute top-2.5 right-2.5 text-[11px] px-2 py-0.5 rounded backdrop-blur-xs font-medium ${
                    cow.healthStatus === 'Healthy'
                      ? 'bg-emerald-950/80 text-emerald-200'
                      : 'bg-amber-950/80 text-amber-200'
                  }`}>
                    {cow.healthStatus}
                  </div>
                </div>

                {/* Content */}
                <div className="p-4 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs text-stone-500">
                    <span>{cow.breed}</span>
                    <span aria-hidden="true">·</span>
                    <span>{cow.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{cow.ageYears}y {cow.ageMonths}m</span>
                  </div>

                  <h3 className="text-lg font-bold text-stone-900 group-hover:text-amber-800 transition-colors">
                    {cow.name}
                  </h3>

                  {cow.category === 'Milking Cow' ? (
                    <div className="flex items-center gap-1.5 text-xs text-amber-900 font-medium">
                      <Droplets className="w-3.5 h-3.5 text-amber-700" />
                      <span>Avg: <strong className="font-mono-data">{cow.dailyMilkAverageLiters} L/day</strong></span>
                      <span className="text-stone-400 font-normal">· Cycle #{cow.lactationCycle}</span>
                    </div>
                  ) : (
                    <div className="text-xs text-stone-500">
                      Weight: <span className="font-mono-data text-stone-700">{cow.weightKg} kg</span>
                    </div>
                  )}

                  <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed pt-1">
                    {cow.notes}
                  </p>
                </div>
              </div>

              {/* Footer / Sponsorship Status */}
              <div className="p-4 pt-0">
                <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                  {cow.isAdopted ? (
                    <span className="text-stone-500 truncate max-w-[150px]">
                      Sponsored: <strong className="text-stone-800">{cow.sponsorName}</strong>
                    </span>
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setAdoptingCow(cow);
                      }}
                      className="text-amber-800 hover:text-amber-950 font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Heart className="w-3.5 h-3.5 text-rose-500" />
                      <span>Sponsor Seva</span>
                    </button>
                  )}

                  <span className="text-stone-400 group-hover:text-amber-800 flex items-center gap-0.5 text-xs font-medium">
                    Profile <ArrowUpRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modals */}
      <CowProfileModal
        cow={selectedCow}
        onClose={() => setSelectedCow(null)}
        onLogYieldForCow={onLogYieldForCow}
        onLogHealthForCow={onLogHealthForCow}
      />

      <AddCowModal
        isOpen={isAddCowOpen}
        onClose={() => setIsAddCowOpen(false)}
      />

      <AdoptionModal
        cow={adoptingCow}
        isOpen={!!adoptingCow}
        onClose={() => setAdoptingCow(null)}
      />
    </div>
  );
};
