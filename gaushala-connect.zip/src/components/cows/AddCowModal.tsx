import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { CowBreed, CowCategory } from '../../types';
import { X, Check } from 'lucide-react';

interface AddCowModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AddCowModal: React.FC<AddCowModalProps> = ({ isOpen, onClose }) => {
  const { addCow } = useGaushala();

  const [name, setName] = useState('');
  const [tagNumber, setTagNumber] = useState('');
  const [breed, setBreed] = useState<CowBreed>('Gir');
  const [gender, setGender] = useState<'Female' | 'Male'>('Female');
  const [category, setCategory] = useState<CowCategory>('Milking Cow');
  const [ageYears, setAgeYears] = useState(4);
  const [ageMonths, setAgeMonths] = useState(2);
  const [weightKg, setWeightKg] = useState(380);
  const [lactationCycle, setLactationCycle] = useState(2);
  const [dailyMilkAverageLiters, setDailyMilkAverageLiters] = useState(12.5);
  const [pedigreeMother, setPedigreeMother] = useState('');
  const [pedigreeFather, setPedigreeFather] = useState('');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !tagNumber.trim()) return;

    addCow({
      name: name.trim(),
      tagNumber: tagNumber.trim().toUpperCase(),
      breed,
      gender,
      category,
      ageYears: Number(ageYears),
      ageMonths: Number(ageMonths),
      weightKg: Number(weightKg),
      lactationCycle: Number(lactationCycle),
      dailyMilkAverageLiters: category === 'Milking Cow' ? Number(dailyMilkAverageLiters) : 0,
      photoUrl: '/src/assets/images/cow_gir_portrait_1793051162764.jpg',
      joinedDate: new Date().toISOString().split('T')[0],
      isAdopted: false,
      pedigreeMother: pedigreeMother.trim() || 'Desi Sangam Lineage',
      pedigreeFather: pedigreeFather.trim() || 'Gaushala Breeding Nandi',
      notes: notes.trim() || 'Newly registered resident in good condition.',
      healthStatus: 'Healthy',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="bg-white rounded-xl max-w-xl w-full p-6 md:p-8 shadow-2xl border border-stone-200 relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-700 rounded-full transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <h3 className="text-lg font-bold text-stone-900">
              Register New Cow / Calf to Herd
            </h3>
            <p className="text-xs text-stone-500">
              Record tag identity, breed lineage, and physiological lifecycle stage.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Cow Name *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Radharani"
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block font-medium text-stone-700 mb-1">Tag Number *</label>
              <input
                type="text"
                required
                value={tagNumber}
                onChange={(e) => setTagNumber(e.target.value)}
                placeholder="e.g. GIR-215"
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white uppercase font-mono-data focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Breed</label>
              <select
                value={breed}
                onChange={(e) => setBreed(e.target.value as CowBreed)}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                <option value="Gir">Gir (Gujarat)</option>
                <option value="Sahiwal">Sahiwal (Punjab)</option>
                <option value="Tharparkar">Tharparkar (Rajasthan)</option>
                <option value="Rathi">Rathi (Bikaner)</option>
                <option value="Red Sindhi">Red Sindhi</option>
                <option value="Kankrej">Kankrej</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as 'Female' | 'Male')}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                <option value="Female">Female (Cow)</option>
                <option value="Male">Male (Nandi / Ox)</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">Lifecycle Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as CowCategory)}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                <option value="Milking Cow">Milking Cow</option>
                <option value="Dry Cow">Dry Cow</option>
                <option value="Pregnant">Pregnant</option>
                <option value="Heifer (Young Female)">Heifer</option>
                <option value="Calf">Calf</option>
                <option value="Elderly / Retired">Elderly / Retired</option>
                <option value="Nandi (Bull)">Nandi (Bull)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Age (Years)</label>
              <input
                type="number"
                min="0"
                max="25"
                value={ageYears}
                onChange={(e) => setAgeYears(Number(e.target.value))}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data"
              />
            </div>
            <div>
              <label className="block font-medium text-stone-700 mb-1">Months</label>
              <input
                type="number"
                min="0"
                max="11"
                value={ageMonths}
                onChange={(e) => setAgeMonths(Number(e.target.value))}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data"
              />
            </div>
            <div>
              <label className="block font-medium text-stone-700 mb-1">Weight (kg)</label>
              <input
                type="number"
                min="30"
                max="900"
                value={weightKg}
                onChange={(e) => setWeightKg(Number(e.target.value))}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data"
              />
            </div>
            <div>
              <label className="block font-medium text-stone-700 mb-1">Lactation #</label>
              <input
                type="number"
                min="0"
                max="12"
                value={lactationCycle}
                onChange={(e) => setLactationCycle(Number(e.target.value))}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data"
              />
            </div>
          </div>

          {category === 'Milking Cow' && (
            <div>
              <label className="block font-medium text-stone-700 mb-1">
                Expected Daily Milk Yield (Liters/day)
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="35"
                value={dailyMilkAverageLiters}
                onChange={(e) => setDailyMilkAverageLiters(Number(e.target.value))}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Mother (Dam / Lineage)</label>
              <input
                type="text"
                value={pedigreeMother}
                onChange={(e) => setPedigreeMother(e.target.value)}
                placeholder="e.g. Kamadhenu (GIR-204)"
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white"
              />
            </div>
            <div>
              <label className="block font-medium text-stone-700 mb-1">Father (Sire / Nandi)</label>
              <input
                type="text"
                value={pedigreeFather}
                onChange={(e) => setPedigreeFather(e.target.value)}
                placeholder="e.g. Nandi Rudra"
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">Caretaker Notes & Temperament</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Calm demeanor, responds well to bell chimes, prefers green napier feed."
              className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white"
            />
          </div>

          <div className="pt-3 border-t border-stone-200 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-stone-300 hover:bg-stone-100 rounded-lg text-stone-700 font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white rounded-lg font-semibold shadow-sm transition-colors cursor-pointer"
            >
              Register Cow
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
