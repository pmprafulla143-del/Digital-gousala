import React from 'react';
import { Product } from '../../types';
import { X, Check, ShieldCheck, Heart, Sparkles, AlertCircle } from 'lucide-react';
import { useGaushala } from '../../context/GaushalaContext';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onOpenSubscription?: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onOpenSubscription,
}) => {
  const { addToCart } = useGaushala();
  const [qty, setQty] = React.useState(1);
  const [added, setAdded] = React.useState(false);

  if (!product) return null;

  const handleAdd = () => {
    addToCart(product, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6">
      <div 
        className="bg-white rounded-xl max-w-3xl w-full overflow-hidden shadow-2xl border border-stone-200 relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-stone-500 hover:text-stone-800 bg-white/90 rounded-full shadow-xs transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Image & Trust Column */}
          <div className="relative bg-stone-100 flex flex-col justify-center items-center p-6 border-b md:border-b-0 md:border-r border-stone-200">
            <div className="w-full aspect-4/3 rounded-lg overflow-hidden bg-white shadow-xs">
              <img
                src={product.image}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>

            <div className="mt-6 w-full space-y-3 text-xs text-stone-600">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>100% Lab Tested A2 Beta-Casein Certified</span>
              </div>
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-amber-700 shrink-0" />
                <span>Ahimsa Guaranteed: Calves Drink First</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-700 shrink-0" />
                <span>Wood-Fire Slow Churned in Earthen & Brass Vessels</span>
              </div>
            </div>
          </div>

          {/* Details & Purchase Column */}
          <div className="p-6 md:p-8 flex flex-col justify-between">
            <div>
              {/* Category & Status Metadata (Clean text, no pill clutter) */}
              <div className="flex items-center gap-2 text-xs text-stone-500 mb-2">
                <span>{product.category}</span>
                <span aria-hidden="true">·</span>
                <span>{product.unit}</span>
                <span aria-hidden="true">·</span>
                <span className={product.inStockQty > 0 ? 'text-emerald-700 font-medium' : 'text-rose-700 font-medium'}>
                  {product.inStockQty > 0 ? `In Stock (${product.inStockQty})` : 'Temporarily Out of Stock'}
                </span>
              </div>

              <h2 className="text-xl md:text-2xl font-bold text-stone-900 leading-snug">
                {product.name}
              </h2>

              <div className="mt-3 flex items-baseline gap-3">
                <span className="text-2xl font-bold font-mono-data text-stone-900">
                  ₹{product.price.toLocaleString('en-IN')}
                </span>
                <span className="text-xs text-stone-500">Inclusive of all taxes</span>
              </div>

              <p className="mt-4 text-sm text-stone-700 leading-relaxed">
                {product.description}
              </p>

              {/* Vedic Benefits Callout */}
              <div className="mt-4 p-3.5 bg-amber-50/80 rounded-lg border border-amber-200/80">
                <h4 className="text-xs font-semibold text-amber-900 mb-1">
                  Vedic & Ayurvedic Merits
                </h4>
                <p className="text-xs text-amber-800 leading-relaxed">
                  {product.vedicBenefits}
                </p>
              </div>

              {/* Key Features List */}
              <div className="mt-4">
                <h4 className="text-xs font-semibold text-stone-800 mb-2">Purity Invariants</h4>
                <ul className="space-y-1.5 text-xs text-stone-600">
                  {product.features.map((feat, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-600" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {product.manufacturingYieldRatio && (
                <div className="mt-4 text-xs text-stone-500 flex items-center gap-1.5">
                  <span className="font-medium text-stone-700">Yield Ratio:</span>
                  <span>{product.manufacturingYieldRatio}</span>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="mt-8 pt-4 border-t border-stone-200">
              <div className="flex items-center gap-3">
                {/* Quantity Stepper */}
                <div className="flex items-center border border-stone-300 rounded-lg overflow-hidden bg-stone-50">
                  <button
                    onClick={() => setQty(Math.max(1, qty - 1))}
                    className="px-3 py-2 text-stone-600 hover:bg-stone-200 active:bg-stone-300 transition-colors text-sm cursor-pointer"
                  >
                    -
                  </button>
                  <span className="px-3 py-2 text-sm font-semibold font-mono-data text-stone-900 min-w-8 text-center">
                    {qty}
                  </span>
                  <button
                    onClick={() => setQty(qty + 1)}
                    className="px-3 py-2 text-stone-600 hover:bg-stone-200 active:bg-stone-300 transition-colors text-sm cursor-pointer"
                  >
                    +
                  </button>
                </div>

                {/* Primary Add to Cart */}
                <button
                  onClick={handleAdd}
                  disabled={product.inStockQty <= 0}
                  className={`flex-1 py-2.5 px-4 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    product.inStockQty <= 0
                      ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                      : added
                      ? 'bg-emerald-700 text-white'
                      : 'bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white shadow-sm'
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Added to Bag!</span>
                    </>
                  ) : (
                    <span>Add to Bag · ₹{(product.price * qty).toLocaleString('en-IN')}</span>
                  )}
                </button>
              </div>

              {product.isSubscriptionAvailable && onOpenSubscription && (
                <div className="mt-3 text-center">
                  <button
                    onClick={() => {
                      onClose();
                      onOpenSubscription();
                    }}
                    className="text-xs text-amber-800 hover:text-amber-950 font-medium underline cursor-pointer"
                  >
                    Looking for recurring morning delivery? Start daily milk subscription →
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
