import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { Cow, CowAdoption } from '../../types';
import { X, Award, Heart, Check, Printer } from 'lucide-react';

interface AdoptionModalProps {
  cow: Cow | null;
  isOpen: boolean;
  onClose: () => void;
}

export const AdoptionModal: React.FC<AdoptionModalProps> = ({ cow, isOpen, onClose }) => {
  const { adoptCow } = useGaushala();

  const [donorName, setDonorName] = useState('');
  const [donorEmail, setDonorEmail] = useState('');
  const [donorPhone, setDonorPhone] = useState('');
  const [durationMonths, setDurationMonths] = useState<number>(6);
  const [monthlyAmount, setMonthlyAmount] = useState<number>(2100);
  const [message, setMessage] = useState('');
  const [adoptionRecord, setAdoptionRecord] = useState<CowAdoption | null>(null);

  if (!isOpen || !cow) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!donorName || !donorPhone) return;

    const record = adoptCow({
      cowId: cow.id,
      donorName,
      donorEmail,
      donorPhone,
      durationMonths,
      monthlyAmount,
      message,
    });

    setAdoptionRecord(record);
  };

  const handleClose = () => {
    setAdoptionRecord(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="bg-white rounded-xl max-w-xl w-full p-6 md:p-8 shadow-2xl border border-stone-200 relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-700 rounded-full transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {adoptionRecord ? (
          /* Digital Blessing Certificate */
          <div className="space-y-4">
            <div className="border-4 border-double border-amber-700/60 p-6 rounded-lg bg-stone-50 text-center relative overflow-hidden">
              <div className="text-amber-800 font-serif-brand font-bold text-lg tracking-widest uppercase">
                श्री सुरभि गौ सेवा न्यास
              </div>
              <div className="text-xs uppercase tracking-wider text-amber-900 font-medium mt-0.5">
                Surabhi Vedic Sanctuary & Gaushala
              </div>
              <div className="my-3 h-px bg-amber-300 w-32 mx-auto" />

              <h3 className="text-xl font-serif-brand font-bold text-stone-900">
                Gau Seva & Adoption Certificate
              </h3>
              <p className="text-xs font-mono-data text-stone-500 mt-1">
                Certificate ID: {adoptionRecord.certificateId}
              </p>

              <div className="mt-4 flex items-center justify-center gap-3">
                <img
                  src={cow.photoUrl}
                  alt={cow.name}
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-full object-cover border-2 border-amber-600 shadow-sm"
                />
                <div className="text-left text-xs">
                  <div className="font-bold text-stone-900 text-sm">{cow.name}</div>
                  <div className="text-stone-600">Tag: {cow.tagNumber} · Breed: {cow.breed}</div>
                  <div className="text-stone-500">Status: Fully Sponsored</div>
                </div>
              </div>

              <div className="mt-4 text-xs text-stone-700 leading-relaxed max-w-md mx-auto">
                This certificate gratefully honors <strong className="text-stone-900">{adoptionRecord.donorName}</strong> for their noble patronage and sacred Gau Seva towards providing organic fodder, Ayurvedic wellness, and lifelong shelter.
              </div>

              <div className="mt-4 pt-3 border-t border-amber-200 flex justify-between items-center text-xs text-stone-600 px-4">
                <div>
                  <span className="block text-stone-400">Tenure</span>
                  <span className="font-semibold text-stone-800">{adoptionRecord.durationMonths} Months</span>
                </div>
                <div>
                  <span className="block text-stone-400">Seva Offering</span>
                  <span className="font-mono-data font-semibold text-stone-800">₹{adoptionRecord.totalDonation.toLocaleString('en-IN')}</span>
                </div>
                <div>
                  <span className="block text-stone-400">Effective Date</span>
                  <span className="font-semibold text-stone-800">{adoptionRecord.startDate}</span>
                </div>
              </div>

              <div className="mt-4 text-xs font-serif-brand text-amber-800 italic">
                "गावो विश्वस्य मातरः" — The Cow is the Mother of the Universe
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 px-4 border border-stone-300 hover:bg-stone-100 rounded-lg text-xs font-medium text-stone-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print / Save Certificate</span>
              </button>
              <button
                onClick={handleClose}
                className="flex-1 py-2 px-4 bg-amber-800 hover:bg-amber-900 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          /* Form */
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <div className="flex items-center gap-1.5 text-amber-800 font-semibold mb-1">
                <Heart className="w-4 h-4" />
                <span>Lifelong Ahimsa Sponsorship</span>
              </div>
              <h3 className="text-lg font-bold text-stone-900">
                Sponsor & Adopt {cow.name} ({cow.tagNumber})
              </h3>
              <p className="text-xs text-stone-500">
                100% of your tax-deductible seva funds green fodder, mineral supplements, and 24/7 veterinary care.
              </p>
            </div>

            {/* Cow Card Preview */}
            <div className="p-3 bg-stone-50 rounded-lg border border-stone-200 flex items-center gap-3">
              <img
                src={cow.photoUrl}
                alt={cow.name}
                referrerPolicy="no-referrer"
                className="w-14 h-14 rounded-lg object-cover border border-stone-200"
              />
              <div className="text-xs">
                <h4 className="font-semibold text-stone-900">{cow.name} ({cow.breed} Cow)</h4>
                <p className="text-stone-500">Age: {cow.ageYears} Years {cow.ageMonths} Mos · {cow.category}</p>
                <p className="text-stone-600 line-clamp-1">{cow.notes}</p>
              </div>
            </div>

            {/* Duration Options */}
            <div>
              <label className="block font-medium text-stone-700 mb-1.5">Sponsorship Duration</label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { months: 1, label: '1 Month' },
                  { months: 3, label: '3 Months' },
                  { months: 6, label: '6 Months' },
                  { months: 12, label: '1 Year' },
                ].map((item) => (
                  <button
                    key={item.months}
                    type="button"
                    onClick={() => setDurationMonths(item.months)}
                    className={`py-2 text-center rounded-lg border font-semibold transition-colors cursor-pointer ${
                      durationMonths === item.months
                        ? 'bg-amber-800 text-white border-amber-800'
                        : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Monthly Seva Amount */}
            <div>
              <label className="block font-medium text-stone-700 mb-1.5">Monthly Contribution</label>
              <div className="grid grid-cols-3 gap-2">
                {[1100, 2100, 5100].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setMonthlyAmount(amt)}
                    className={`py-2 text-center rounded-lg border font-mono-data font-semibold transition-colors cursor-pointer ${
                      monthlyAmount === amt
                        ? 'bg-amber-800 text-white border-amber-800'
                        : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    ₹{amt.toLocaleString('en-IN')}/mo
                  </button>
                ))}
              </div>
            </div>

            {/* Donor Fields */}
            <div className="space-y-3 pt-2 border-t border-stone-200">
              <div>
                <label className="block font-medium text-stone-700 mb-1">Donor / Family Name *</label>
                <input
                  type="text"
                  required
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  placeholder="e.g. Radheshyam & Sangeeta Gupta"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    value={donorPhone}
                    onChange={(e) => setDonorPhone(e.target.value)}
                    placeholder="+91 98200 12345"
                    className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Email (for Certificate)</label>
                  <input
                    type="email"
                    value={donorEmail}
                    onChange={(e) => setDonorEmail(e.target.value)}
                    placeholder="donor@example.com"
                    className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">Prayer / Dedication Message (Optional)</label>
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="e.g. Dedicated for parents' 50th wedding anniversary"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>

            {/* Total */}
            <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-stone-700 font-medium block">Total Seva Offering</span>
                <span className="text-stone-500 text-xs">For {durationMonths} months sponsorship</span>
              </div>
              <span className="text-base font-bold font-mono-data text-stone-900">
                ₹{(durationMonths * monthlyAmount).toLocaleString('en-IN')}
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              Confirm Adoption & Generate Certificate
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
