import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { Product, ProductCategory, Cow } from '../../types';
import { ProductDetailModal } from './ProductDetailModal';
import { MilkSubscriptionModal } from './MilkSubscriptionModal';
import { AdoptionModal } from './AdoptionModal';
import { 
  Sparkles, 
  ShieldCheck, 
  HeartHandshake, 
  Leaf, 
  ArrowRight, 
  Check, 
  Search,
  Droplets,
  CalendarCheck
} from 'lucide-react';

export const Storefront: React.FC = () => {
  const { products, addToCart, cows, setActiveTab } = useGaushala();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isSubscriptionOpen, setIsSubscriptionOpen] = useState(false);
  const [adoptingCow, setAdoptingCow] = useState<Cow | null>(null);
  const [addedProductId, setAddedProductId] = useState<string | null>(null);

  const categories = ['All', 'A2 Dairy', 'Panchagavya & Organic Farming', 'Pooja & Wellness', 'Gau Grass & Seva'];

  const filteredProducts = products.filter((p) => {
    const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleQuickAdd = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
    setAddedProductId(product.id);
    setTimeout(() => setAddedProductId(null), 1200);
  };

  // Milking and adoptable cows to spotlight
  const adoptableCows = cows.filter(c => !c.isAdopted).slice(0, 3);

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-2xl bg-stone-900 text-white shadow-xl">
        <div className="absolute inset-0">
          <img
            src="/src/assets/images/hero_gaushala_pasture_1793051161817.jpg"
            alt="Surabhi Vedic Gaushala Sanctuary"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-45 transform scale-102"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-900/60 to-stone-900/30" />
        </div>

        <div className="relative max-w-4xl mx-auto px-6 py-16 sm:py-24 text-center">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-amber-300 mb-4">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Sacred Ahimsa Sanctuary & Vedic Dairy</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-serif-brand font-bold tracking-tight text-white leading-tight max-w-3xl mx-auto [text-wrap:balance]">
            Pure A2 Vedic Products From Respected Indigenous Cows
          </h1>

          <p className="mt-4 text-sm sm:text-base text-stone-200 max-w-2xl mx-auto leading-relaxed [text-wrap:balance]">
            Handcrafted with Vedic traditions. Our calves drink their full mother's share first before morning milking. 100% of proceeds support lifelong shelter for abandoned and elderly cows.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <a
              href="#products-section"
              className="py-3 px-6 bg-amber-700 hover:bg-amber-800 active:bg-amber-900 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              Explore A2 Storefront
            </a>
            <button
              onClick={() => setIsSubscriptionOpen(true)}
              className="py-3 px-6 bg-white/10 hover:bg-white/20 active:bg-white/30 text-white backdrop-blur-xs text-xs font-semibold rounded-lg border border-white/20 transition-colors cursor-pointer"
            >
              Start Daily Milk Delivery
            </button>
            <a
              href="#seva-section"
              className="py-3 px-6 bg-amber-950/80 hover:bg-amber-900 text-amber-200 border border-amber-600/40 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Adopt a Cow / Gau Seva
            </a>
          </div>
        </div>

        {/* 4-Item Proof / Invariants Strip */}
        <div className="relative border-t border-white/10 bg-black/40 backdrop-blur-xs grid grid-cols-2 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-white/10 text-xs">
          <div className="p-4 flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-semibold text-white">100% Indigenous Breeds</div>
              <div className="text-stone-300">Gir, Sahiwal & Tharparkar</div>
            </div>
          </div>
          <div className="p-4 flex items-center gap-3">
            <HeartHandshake className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-semibold text-white">Ahimsa Milking Protocol</div>
              <div className="text-stone-300">Calves feed fully before milking</div>
            </div>
          </div>
          <div className="p-4 flex items-center gap-3">
            <Droplets className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-semibold text-white">5-Step Vedic Bilona</div>
              <div className="text-stone-300">Curd-churned on slow wood fire</div>
            </div>
          </div>
          <div className="p-4 flex items-center gap-3">
            <Leaf className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-semibold text-white">Zero Hormones or Chemicals</div>
              <div className="text-stone-300">100% Grass-fed organic pasture</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section id="products-section" className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-stone-900 font-serif-brand">
              Sacred Products & A2 Dairy
            </h2>
            <p className="text-xs text-stone-500 mt-1">
              Directly prepared at our sanctuary and lab-certified for pure A2 beta-casein.
            </p>
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Ghee, Milk, Compost..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-stone-200 rounded-lg text-stone-900 focus:outline-none focus:ring-1 focus:ring-amber-600"
            />
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => {
            const isAdded = addedProductId === product.id;
            const isOutOfStock = product.inStockQty <= 0;

            return (
              <div
                key={product.id}
                onClick={() => setSelectedProduct(product)}
                className="group bg-white rounded-xl border border-stone-200 overflow-hidden hover:border-amber-400/80 hover:shadow-md transition-all flex flex-col cursor-pointer"
              >
                {/* Product Image Slot */}
                <div className="relative aspect-4/3 bg-stone-100 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                  {product.category === 'Gau Grass & Seva' && (
                    <div className="absolute top-3 left-3 bg-amber-900/90 text-amber-200 text-[11px] font-medium px-2 py-0.5 rounded backdrop-blur-xs">
                      100% Charitable Seva
                    </div>
                  )}
                </div>

                {/* Card Content */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Clean unboxed metadata separated by typographic dots */}
                    <div className="flex items-center gap-2 text-xs text-stone-500 mb-1.5">
                      <span>{product.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{product.unit}</span>
                      <span aria-hidden="true">·</span>
                      <span className={isOutOfStock ? 'text-rose-700' : 'text-emerald-700 font-medium'}>
                        {isOutOfStock ? 'Sold Out' : `Stock: ${product.inStockQty}`}
                      </span>
                    </div>

                    <h3 className="text-base font-semibold text-stone-900 group-hover:text-amber-800 transition-colors leading-snug">
                      {product.name}
                    </h3>

                    <p className="mt-2 text-xs text-stone-600 line-clamp-2 leading-relaxed">
                      {product.shortDesc}
                    </p>
                  </div>

                  {/* Pricing and Action */}
                  <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
                    <div>
                      <span className="text-lg font-bold font-mono-data text-stone-900">
                        ₹{product.price.toLocaleString('en-IN')}
                      </span>
                      <span className="text-stone-400 text-xs ml-1">/{product.unit.split(' ')[0]}</span>
                    </div>

                    <button
                      onClick={(e) => handleQuickAdd(product, e)}
                      disabled={isOutOfStock}
                      className={`py-1.5 px-3 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
                        isOutOfStock
                          ? 'bg-stone-100 text-stone-400 cursor-not-allowed'
                          : isAdded
                          ? 'bg-emerald-700 text-white'
                          : 'bg-stone-900 text-white hover:bg-amber-800 active:bg-amber-900'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Added</span>
                        </>
                      ) : (
                        <span>Add</span>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Daily Fresh Milk Subscription Banner */}
      <section className="bg-stone-100 border border-stone-200 rounded-2xl p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        <div className="lg:col-span-8 space-y-3">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800">
            <CalendarCheck className="w-4 h-4" />
            <span>Recurring Morning Routine</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold font-serif-brand text-stone-900">
            Fresh Raw A2 Milk Delivered Daily to Your Doorstep
          </h3>
          <p className="text-xs sm:text-sm text-stone-600 leading-relaxed max-w-2xl">
            Never run out of pure Vedic milk for your family, children, and morning chai. Delivered directly from the 5:00 AM milking round in sterilized, reusable glass bottles by 7:30 AM.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-stone-700">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-600" />
              <span>Free doorstep bottle delivery</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-600" />
              <span>Pause or adjust days anytime</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-600" />
              <span>₹95/Liter transparent pricing</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 flex justify-start lg:justify-end">
          <button
            onClick={() => setIsSubscriptionOpen(true)}
            className="w-full sm:w-auto py-3 px-6 bg-amber-800 hover:bg-amber-900 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors cursor-pointer"
          >
            Setup Milk Subscription
          </button>
        </div>
      </section>

      {/* Gau Seva & Cow Adoption Spotlight Section */}
      <section id="seva-section" className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-amber-800">
              Gau Seva & Lifelong Ahimsa
            </div>
            <h2 className="text-2xl font-bold font-serif-brand text-stone-900 mt-1">
              Sponsor or Adopt a Resident Mother Cow
            </h2>
            <p className="text-xs text-stone-500 mt-1">
              Provide green Napier fodder, prenatal Ayurvedic care, and lifelong shelter. Receive a framed digital Seva Certificate.
            </p>
          </div>

          <button
            onClick={() => setActiveTab('cows')}
            className="text-xs text-amber-800 hover:text-amber-950 font-semibold flex items-center gap-1 cursor-pointer shrink-0"
          >
            <span>View All {cows.length} Resident Cows</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {adoptableCows.map((cow) => (
            <div
              key={cow.id}
              className="bg-white border border-stone-200 rounded-xl overflow-hidden hover:border-amber-400 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="relative aspect-4/3 bg-stone-100 overflow-hidden">
                  <img
                    src={cow.photoUrl}
                    alt={cow.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3 bg-black/60 text-white text-[11px] font-mono-data px-2 py-0.5 rounded backdrop-blur-xs">
                    Tag: {cow.tagNumber}
                  </div>
                </div>

                <div className="p-4 space-y-2">
                  <div className="flex items-center gap-2 text-xs text-stone-500">
                    <span>{cow.breed} Cow</span>
                    <span aria-hidden="true">·</span>
                    <span>{cow.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{cow.ageYears} yrs</span>
                  </div>

                  <h3 className="text-base font-bold text-stone-900">{cow.name}</h3>
                  <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                    {cow.notes}
                  </p>
                </div>
              </div>

              <div className="p-4 pt-0">
                <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                  <span className="text-xs font-mono-data text-stone-700">₹2,100 / month</span>
                  <button
                    onClick={() => setAdoptingCow(cow)}
                    className="py-1.5 px-3 bg-amber-800 hover:bg-amber-900 text-white rounded-lg text-xs font-medium transition-colors cursor-pointer"
                  >
                    Sponsor Cow
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Modals */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onOpenSubscription={() => setIsSubscriptionOpen(true)}
      />

      <MilkSubscriptionModal
        isOpen={isSubscriptionOpen}
        onClose={() => setIsSubscriptionOpen(false)}
      />

      <AdoptionModal
        cow={adoptingCow}
        isOpen={!!adoptingCow}
        onClose={() => setAdoptingCow(null)}
      />
    </div>
  );
};
