import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { X, CheckCircle, Calendar, Clock, Sparkles } from 'lucide-react';

interface MilkSubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MilkSubscriptionModal: React.FC<MilkSubscriptionModalProps> = ({ isOpen, onClose }) => {
  const { addSubscription } = useGaushala();

  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [dailyLiters, setDailyLiters] = useState<number>(2);
  const [frequency, setFrequency] = useState<'Daily' | 'Alternate Days' | 'Weekdays Only'>('Daily');
  const [deliverySlot, setDeliverySlot] = useState<'Morning (6:00 AM - 7:30 AM)' | 'Evening (5:30 PM - 7:00 PM)'>('Morning (6:00 AM - 7:30 AM)');
  const [confirmed, setConfirmed] = useState(false);

  if (!isOpen) return null;

  // Monthly estimate: ₹95 per liter
  const daysPerMonth = frequency === 'Daily' ? 30 : frequency === 'Alternate Days' ? 15 : 22;
  const monthlyTotal = dailyLiters * daysPerMonth * 95;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !phone || !address) return;

    addSubscription({
      customerName,
      phone,
      address,
      dailyLiters,
      frequency,
      deliverySlot,
      startDate: new Date().toISOString().split('T')[0],
      status: 'Active',
      monthlyEstimate: monthlyTotal,
    });

    setConfirmed(true);
  };

  const handleClose = () => {
    setConfirmed(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="bg-white rounded-xl max-w-lg w-full p-6 md:p-8 shadow-2xl border border-stone-200 relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-700 rounded-full transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {confirmed ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-stone-900">Subscription Activated</h3>
            <p className="text-xs text-stone-600">
              Welcome, <span className="font-semibold">{customerName}</span>. Your pure A2 Vedic milk deliveries will start tomorrow morning.
            </p>

            <div className="p-4 bg-stone-50 rounded-lg text-left text-xs space-y-2 border border-stone-200">
              <div className="flex justify-between">
                <span className="text-stone-500">Volume:</span>
                <span className="font-semibold text-stone-900">{dailyLiters} Liters ({frequency})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Delivery Slot:</span>
                <span className="font-semibold text-stone-900">{deliverySlot}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Est. Monthly Bill:</span>
                <span className="font-mono-data font-semibold text-stone-900">₹{monthlyTotal.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Packaging:</span>
                <span className="font-semibold text-stone-900">Sterilized Glass Bottles (Exchange daily)</span>
              </div>
            </div>

            <button
              onClick={handleClose}
              className="w-full py-2.5 px-4 bg-amber-800 hover:bg-amber-900 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <div className="flex items-center gap-1.5 text-amber-800 font-semibold mb-1">
                <Sparkles className="w-4 h-4" />
                <span>Farm-to-Doorstep Delivery</span>
              </div>
              <h3 className="text-lg font-bold text-stone-900">
                A2 Vedic Milk Daily Subscription
              </h3>
              <p className="text-xs text-stone-500">
                Fresh raw unpasteurized milk from pure Gir & Sahiwal cows delivered before 7:30 AM in sterilized glass bottles.
              </p>
            </div>

            {/* Daily Liters Picker */}
            <div>
              <label className="block font-medium text-stone-700 mb-1.5">
                Daily Quantity (Liters)
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[1, 1.5, 2, 3].map((liters) => (
                  <button
                    key={liters}
                    type="button"
                    onClick={() => setDailyLiters(liters)}
                    className={`py-2 text-center rounded-lg border font-semibold transition-colors cursor-pointer ${
                      dailyLiters === liters
                        ? 'bg-amber-800 text-white border-amber-800'
                        : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    {liters} L
                  </button>
                ))}
              </div>
            </div>

            {/* Frequency */}
            <div>
              <label className="block font-medium text-stone-700 mb-1.5">Delivery Cadence</label>
              <div className="grid grid-cols-3 gap-2">
                {(['Daily', 'Alternate Days', 'Weekdays Only'] as const).map((freq) => (
                  <button
                    key={freq}
                    type="button"
                    onClick={() => setFrequency(freq)}
                    className={`py-2 px-1 text-center rounded-lg border font-medium text-xs transition-colors cursor-pointer ${
                      frequency === freq
                        ? 'bg-amber-800 text-white border-amber-800'
                        : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    {freq}
                  </button>
                ))}
              </div>
            </div>

            {/* Slot */}
            <div>
              <label className="block font-medium text-stone-700 mb-1.5">Delivery Slot</label>
              <div className="space-y-1.5">
                {(['Morning (6:00 AM - 7:30 AM)', 'Evening (5:30 PM - 7:00 PM)'] as const).map((slot) => (
                  <button
                    key={slot}
                    type="button"
                    onClick={() => setDeliverySlot(slot)}
                    className={`w-full py-2 px-3 text-left rounded-lg border text-xs flex items-center gap-2 transition-colors cursor-pointer ${
                      deliverySlot === slot
                        ? 'bg-amber-50 border-amber-700 text-amber-900 font-medium'
                        : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <Clock className="w-3.5 h-3.5 text-stone-400" />
                    <span>{slot}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Customer Details */}
            <div className="space-y-3 pt-2 border-t border-stone-200">
              <div>
                <label className="block font-medium text-stone-700 mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Suman Sharma"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">Mobile Number (for delivery coordinator) *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98765 01234"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">Delivery Address *</label>
                <textarea
                  required
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Flat/House no., Society name, Landmark"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>

            {/* Estimate Summary */}
            <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-stone-600 block">Monthly Estimated Total</span>
                <span className="text-xs text-amber-800">Billed monthly after delivery</span>
              </div>
              <span className="text-base font-bold font-mono-data text-stone-900">
                ₹{monthlyTotal.toLocaleString('en-IN')}
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              Confirm Subscription
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
