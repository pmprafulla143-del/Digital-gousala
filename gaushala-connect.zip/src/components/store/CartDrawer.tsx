import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { X, Trash2, ShieldCheck, HeartHandshake, CheckCircle2, ArrowRight } from 'lucide-react';
import { Order } from '../../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onGoToOrders?: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose, onGoToOrders }) => {
  const { cart, updateCartQty, removeFromCart, placeOrder } = useGaushala();
  
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [donationAmount, setDonationAmount] = useState<number>(51);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [pinCode, setPinCode] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Card' | 'NetBanking' | 'Cash on Delivery'>('UPI');
  const [errorMsg, setErrorMsg] = useState('');
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  if (!isOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const deliveryFee = subtotal === 0 ? 0 : subtotal > 1000 ? 0 : 60;
  const total = subtotal + deliveryFee + donationAmount;

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!name.trim() || !phone.trim() || !address.trim() || !city.trim() || !pinCode.trim()) {
      setErrorMsg('Please complete all required delivery fields.');
      return;
    }

    const result = placeOrder({
      customerName: name.trim(),
      customerPhone: phone.trim(),
      customerEmail: email.trim() || 'devotee@surabhigaushala.org',
      deliveryAddress: address.trim(),
      city: city.trim(),
      pinCode: pinCode.trim(),
      paymentMethod,
      donationAmount,
    });

    if (result.success && result.order) {
      setConfirmedOrder(result.order);
      setIsCheckingOut(false);
    } else {
      setErrorMsg(result.error || 'Failed to place order.');
    }
  };

  const handleClose = () => {
    setConfirmedOrder(null);
    setIsCheckingOut(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-stone-900/60 backdrop-blur-xs flex justify-end">
      <div 
        className="w-full max-w-lg bg-white h-full flex flex-col shadow-2xl relative animate-in slide-in-from-right duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div>
            <h3 className="text-base font-semibold text-stone-900">
              {confirmedOrder ? 'Order Confirmed' : isCheckingOut ? 'Checkout & Shipping' : 'Your Shopping Bag'}
            </h3>
            <p className="text-xs text-stone-500">
              {confirmedOrder ? 'Thank you for supporting our cows' : `${cart.length} item${cart.length === 1 ? '' : 's'} selected`}
            </p>
          </div>
          <button
            onClick={handleClose}
            className="p-2 text-stone-400 hover:text-stone-700 rounded-full hover:bg-stone-200 transition-colors cursor-pointer"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {confirmedOrder ? (
            /* Order Success View */
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-xl font-bold text-stone-900">Jai Gau Mata! Order Placed</h4>
                <p className="text-xs text-stone-500 mt-1">
                  Order Number: <span className="font-mono-data font-semibold text-stone-800">{confirmedOrder.orderNumber}</span>
                </p>
              </div>

              <div className="p-4 bg-amber-50/70 border border-amber-200/80 rounded-lg text-left text-xs text-amber-900 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-amber-800">Status:</span>
                  <span className="font-semibold">{confirmedOrder.orderStatus}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-800">Estimated Delivery:</span>
                  <span className="font-semibold">{confirmedOrder.estimatedDelivery}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-amber-800">Total Paid:</span>
                  <span className="font-mono-data font-semibold">₹{confirmedOrder.totalAmount.toLocaleString('en-IN')}</span>
                </div>
                {confirmedOrder.donationAmount > 0 && (
                  <div className="flex justify-between text-emerald-800 pt-1 border-t border-amber-200">
                    <span>Gau Grass Seva Included:</span>
                    <span className="font-semibold">₹{confirmedOrder.donationAmount}</span>
                  </div>
                )}
              </div>

              <div className="p-3 bg-stone-100 rounded-lg text-xs text-stone-600 text-left">
                <p className="font-medium text-stone-800 mb-1">Automated Inventory Verification:</p>
                <p>Shelter finished stocks have been updated in real-time. A tax-compliant receipt has been recorded.</p>
              </div>

              <div className="pt-4 flex flex-col gap-2">
                {onGoToOrders && (
                  <button
                    onClick={() => {
                      handleClose();
                      onGoToOrders();
                    }}
                    className="w-full py-2.5 px-4 bg-amber-800 hover:bg-amber-900 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors cursor-pointer"
                  >
                    View in Order Management ERP
                  </button>
                )}
                <button
                  onClick={handleClose}
                  className="w-full py-2 px-4 border border-stone-300 hover:bg-stone-50 text-stone-700 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          ) : isCheckingOut ? (
            /* Checkout Form */
            <form onSubmit={handleCheckoutSubmit} className="space-y-4 text-xs">
              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg">
                  {errorMsg}
                </div>
              )}

              <div>
                <label className="block font-medium text-stone-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ramesh Patel"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@domain.com"
                    className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">Delivery Address *</label>
                <textarea
                  required
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="House/Flat number, building, street, landmark"
                  className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">City *</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="e.g. Mumbai"
                    className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-medium text-stone-700 mb-1">PIN / Postal Code *</label>
                  <input
                    type="text"
                    required
                    value={pinCode}
                    onChange={(e) => setPinCode(e.target.value)}
                    placeholder="e.g. 400001"
                    className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-stone-700 mb-1">Payment Method</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['UPI', 'Card', 'NetBanking', 'Cash on Delivery'] as const).map((method) => (
                    <button
                      type="button"
                      key={method}
                      onClick={() => setPaymentMethod(method)}
                      className={`p-2.5 rounded-lg border text-left font-medium transition-colors cursor-pointer ${
                        paymentMethod === method
                          ? 'border-amber-700 bg-amber-50 text-amber-900'
                          : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setIsCheckingOut(false)}
                  className="px-4 py-2 border border-stone-300 hover:bg-stone-100 rounded-lg text-stone-700 font-medium cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white rounded-lg font-semibold shadow-sm transition-colors cursor-pointer"
                >
                  Confirm Order · ₹{total.toLocaleString('en-IN')}
                </button>
              </div>
            </form>
          ) : cart.length === 0 ? (
            /* Empty Cart */
            <div className="text-center py-16 space-y-3">
              <p className="text-sm font-medium text-stone-600">Your bag is empty.</p>
              <p className="text-xs text-stone-400">
                Browse our pure A2 Bilona Ghee, fresh farm milk, vermicompost, and handmade dhoop.
              </p>
              <button
                onClick={handleClose}
                className="mt-4 px-4 py-2 bg-amber-800 text-white text-xs font-semibold rounded-lg hover:bg-amber-900 transition-colors cursor-pointer"
              >
                Browse Products
              </button>
            </div>
          ) : (
            /* Itemized List */
            <div className="space-y-4">
              <div className="divide-y divide-stone-100">
                {cart.map((item) => (
                  <div key={item.product.id} className="py-3 flex items-center gap-3">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 rounded-lg object-cover bg-stone-100 border border-stone-200 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-semibold text-stone-900 truncate">
                        {item.product.name}
                      </h4>
                      <p className="text-xs text-stone-500 font-mono-data">
                        ₹{item.product.price.toLocaleString('en-IN')} · {item.product.unit}
                      </p>
                      <div className="mt-1 flex items-center gap-2">
                        <div className="flex items-center border border-stone-300 rounded overflow-hidden">
                          <button
                            onClick={() => updateCartQty(item.product.id, item.quantity - 1)}
                            className="px-2 py-0.5 text-xs text-stone-600 hover:bg-stone-200 cursor-pointer"
                          >
                            -
                          </button>
                          <span className="px-2 py-0.5 text-xs font-semibold font-mono-data">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateCartQty(item.product.id, item.quantity + 1)}
                            className="px-2 py-0.5 text-xs text-stone-600 hover:bg-stone-200 cursor-pointer"
                          >
                            +
                          </button>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-stone-400 hover:text-rose-600 p-1 cursor-pointer transition-colors"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-bold font-mono-data text-stone-900">
                        ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Gau Grass Donation Option */}
              <div className="p-3.5 bg-amber-50/70 border border-amber-200/80 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <HeartHandshake className="w-4 h-4 text-amber-800" />
                  <span className="text-xs font-semibold text-amber-900">
                    Add Gau Grass & Fodder Seva
                  </span>
                </div>
                <p className="text-xs text-stone-600 mb-2.5">
                  Directly feeds fresh green Napier grass to our sanctuary cows.
                </p>
                <div className="flex items-center gap-2">
                  {[0, 51, 101, 251].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setDonationAmount(amt)}
                      className={`px-2.5 py-1 text-xs rounded font-medium transition-colors cursor-pointer ${
                        donationAmount === amt
                          ? 'bg-amber-800 text-white'
                          : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
                      }`}
                    >
                      {amt === 0 ? 'None' : `+₹${amt}`}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer with Summary (Only shown when not confirmed and cart has items) */}
        {!confirmedOrder && cart.length > 0 && !isCheckingOut && (
          <div className="p-6 border-t border-stone-200 bg-stone-50 space-y-3 text-xs">
            <div className="space-y-1.5 text-stone-600">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono-data text-stone-900">₹{subtotal.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>Eco Delivery & Packaging</span>
                <span className="font-mono-data text-stone-900">
                  {deliveryFee === 0 ? 'FREE (Orders over ₹1,000)' : `₹${deliveryFee}`}
                </span>
              </div>
              {donationAmount > 0 && (
                <div className="flex justify-between text-amber-900">
                  <span>Gau Grass Seva</span>
                  <span className="font-mono-data">₹{donationAmount}</span>
                </div>
              )}
              <div className="flex justify-between font-semibold text-sm text-stone-900 pt-2 border-t border-stone-200">
                <span>Total</span>
                <span className="font-mono-data">₹{total.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <button
              onClick={() => setIsCheckingOut(true)}
              className="w-full py-2.5 px-4 bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white rounded-lg font-semibold shadow-sm transition-colors flex items-center justify-center gap-2 cursor-pointer text-sm"
            >
              <span>Proceed to Shipping</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-1.5 text-stone-500 text-xs text-center">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
              <span>Safe Delivery · 100% Ahimsa Purity Certified</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
