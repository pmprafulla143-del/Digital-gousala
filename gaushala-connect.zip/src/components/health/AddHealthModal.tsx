import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { Cow, HealthRecordType, HealthSeverity } from '../../types';
import { X, Calendar } from 'lucide-react';

interface AddHealthModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedCow?: Cow | null;
}

export const AddHealthModal: React.FC<AddHealthModalProps> = ({
  isOpen,
  onClose,
  preselectedCow,
}) => {
  const { cows, addHealthRecord } = useGaushala();

  const [cowId, setCowId] = useState(preselectedCow ? preselectedCow.id : cows[0]?.id || '');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [type, setType] = useState<HealthRecordType>('Vaccination');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [veterinarian, setVeterinarian] = useState('Dr. Anand Joshi (B.V.Sc)');
  const [severity, setSeverity] = useState<HealthSeverity>('Routine');
  const [medications, setMedications] = useState('');
  const [dosage, setDosage] = useState('');
  const [nextDueDate, setNextDueDate] = useState('');
  const [recoveryStatus, setRecoveryStatus] = useState<'Resolved' | 'Under Treatment' | 'Observation'>('Resolved');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cow = cows.find((c) => c.id === cowId);
    if (!cow || !title.trim()) return;

    addHealthRecord({
      cowId: cow.id,
      cowName: cow.name,
      cowTag: cow.tagNumber,
      date,
      type,
      title: title.trim(),
      description: description.trim() || 'Standard veterinary protocol completed.',
      veterinarian: veterinarian.trim(),
      severity,
      medications: medications.trim(),
      dosage: dosage.trim(),
      nextDueDate: nextDueDate || undefined,
      recoveryStatus,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="bg-white rounded-xl max-w-xl w-full p-6 md:p-8 shadow-2xl border border-stone-200 relative animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-stone-400 hover:text-stone-700 rounded-full transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <h3 className="text-lg font-bold text-stone-900">
              Log Veterinary Checkup & Health Record
            </h3>
            <p className="text-xs text-stone-500">
              Record vaccinations, deworming, clinical diagnosis, and Ayurvedic herbal care.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Select Cow *</label>
              <select
                value={cowId}
                onChange={(e) => setCowId(e.target.value)}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                {cows.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} (#{c.tagNumber} · {c.breed})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">Date Administered</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Category</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as HealthRecordType)}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                <option value="Vaccination">Vaccination (FMD / HS / BQ)</option>
                <option value="Deworming">Deworming Cycle</option>
                <option value="Medical Treatment">Clinical Treatment / Injury</option>
                <option value="Routine Checkup">Routine Physical Checkup</option>
                <option value="Ayurvedic Herbals">Ayurvedic Tonic / Herbs</option>
                <option value="Reproductive Care">Prenatal & Reproductive Care</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">Severity / Urgency</label>
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value as HealthSeverity)}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                <option value="Routine">Routine / Preventive</option>
                <option value="Mild">Mild Observation</option>
                <option value="Moderate">Moderate (Requires Follow-up)</option>
                <option value="Critical">Critical / Isolation</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">Clinical Title / Diagnosis *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Bi-Annual Polyvalent FMD Booster or Teat Conditioning"
              className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">Clinical Observations & Findings</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Clinical details, symptoms observed, body temperature, or vitals..."
              className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Attending Veterinarian</label>
              <input
                type="text"
                value={veterinarian}
                onChange={(e) => setVeterinarian(e.target.value)}
                placeholder="Dr. Name"
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">Recovery Status</label>
              <select
                value={recoveryStatus}
                onChange={(e) => setRecoveryStatus(e.target.value as any)}
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                <option value="Resolved">Resolved / Healthy</option>
                <option value="Under Treatment">Active Treatment</option>
                <option value="Observation">Under Daily Observation</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-stone-700 mb-1">Medication / Vaccine Brand</label>
              <input
                type="text"
                value={medications}
                onChange={(e) => setMedications(e.target.value)}
                placeholder="e.g. Raksha-Ovac or Panacur Bolus"
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-medium text-stone-700 mb-1">Dosage & Administration</label>
              <input
                type="text"
                value={dosage}
                onChange={(e) => setDosage(e.target.value)}
                placeholder="e.g. 2 ml Deep I/M or 3g oral bolus"
                className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-stone-700 mb-1">Next Scheduled Booster / Due Date</label>
            <input
              type="date"
              value={nextDueDate}
              onChange={(e) => setNextDueDate(e.target.value)}
              className="w-full p-2.5 border border-stone-300 rounded-lg text-stone-900 bg-white font-mono-data focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div className="pt-3 border-t border-stone-200 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-stone-300 hover:bg-stone-100 rounded-lg text-stone-700 font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-800 hover:bg-amber-900 active:bg-amber-950 text-white rounded-lg font-semibold shadow-sm transition-colors cursor-pointer"
            >
              Save Health Record
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
