import React, { useState } from 'react';
import { useGaushala } from '../../context/GaushalaContext';
import { HealthRecord, HealthRecordType, Cow } from '../../types';
import { AddHealthModal } from './AddHealthModal';
import { 
  Stethoscope, 
  Plus, 
  Calendar, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Search,
  Pill,
  Sparkles,
  ShieldCheck
} from 'lucide-react';

interface HealthRecordsProps {
  preselectedCow?: Cow | null;
}

export const HealthRecords: React.FC<HealthRecordsProps> = ({ preselectedCow }) => {
  const { healthRecords, cows } = useGaushala();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [isAddOpen, setIsAddOpen] = useState(false);

  const types = ['All', 'Vaccination', 'Deworming', 'Medical Treatment', 'Routine Checkup', 'Ayurvedic Herbals', 'Reproductive Care'];

  // Metrics
  const totalRecords = healthRecords.length;
  const underTreatmentCount = healthRecords.filter(r => r.recoveryStatus === 'Under Treatment').length;
  const upcomingBoosters = healthRecords.filter(r => r.nextDueDate && new Date(r.nextDueDate) >= new Date()).length;

  const filteredRecords = healthRecords.filter((rec) => {
    const matchesSearch = 
      rec.cowName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.cowTag.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.veterinarian.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (rec.medications && rec.medications.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesType = selectedType === 'All' || rec.type === selectedType;

    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif-brand text-stone-900">
            Veterinary Health & Clinical Logs
          </h1>
          <p className="text-xs text-stone-500 mt-1">
            Tracking bi-annual vaccinations, deworming cycles, Ayurvedic care, and clinical follow-ups.
          </p>
        </div>

        <button
          onClick={() => setIsAddOpen(true)}
          className="self-start md:self-auto py-2.5 px-4 bg-amber-800 hover:bg-amber-900 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Log Health Record</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Total Clinical Logs</span>
            <Stethoscope className="w-4 h-4 text-stone-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-stone-900">{totalRecords}</span>
            <span className="text-xs text-stone-400">interventions recorded</span>
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Active Treatments / Observation</span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-amber-900">{underTreatmentCount}</span>
            <span className="text-xs text-stone-400">cows under active care</span>
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-stone-200">
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>Scheduled Boosters / Due</span>
            <Clock className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono-data text-emerald-800">{upcomingBoosters}</span>
            <span className="text-xs text-stone-400">upcoming deadlines</span>
          </div>
        </div>
      </div>

      {/* Search and Category Filter */}
      <div className="p-4 bg-white rounded-xl border border-stone-200 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by cow name, tag (e.g. GIR-204), diagnosis, medication, or veterinarian..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-900 focus:outline-none focus:ring-1 focus:ring-amber-600"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
          {types.map((t) => (
            <button
              key={t}
              onClick={() => setSelectedType(t)}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                selectedType === t
                  ? 'bg-amber-800 text-white font-medium shadow-xs'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Health Records List */}
      <div className="space-y-4">
        {filteredRecords.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-stone-200 p-6">
            <p className="text-xs text-stone-500">No medical records match your search filter.</p>
          </div>
        ) : (
          filteredRecords.map((record) => (
            <div
              key={record.id}
              className="bg-white rounded-xl border border-stone-200 p-5 hover:border-amber-300 transition-colors space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-stone-100 border border-stone-200 flex items-center justify-center shrink-0">
                    {record.type === 'Vaccination' ? (
                      <ShieldCheck className="w-5 h-5 text-emerald-700" />
                    ) : record.type === 'Ayurvedic Herbals' ? (
                      <Sparkles className="w-5 h-5 text-amber-700" />
                    ) : (
                      <Stethoscope className="w-5 h-5 text-amber-800" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">
                      {record.title}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-stone-500 mt-0.5">
                      <span className="font-semibold text-stone-800">{record.cowName}</span>
                      <span className="font-mono-data text-stone-500">#{record.cowTag}</span>
                      <span aria-hidden="true">·</span>
                      <span>{record.type}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className={`px-2 py-0.5 rounded font-medium ${
                    record.recoveryStatus === 'Resolved'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-amber-50 text-amber-800 border border-amber-200'
                  }`}>
                    {record.recoveryStatus}
                  </span>
                  <span className="font-mono-data text-stone-500 bg-stone-100 px-2 py-0.5 rounded">
                    {record.date}
                  </span>
                </div>
              </div>

              <p className="text-xs text-stone-700 leading-relaxed pl-12">
                {record.description}
              </p>

              <div className="pl-12 pt-2 border-t border-stone-100 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-stone-600">
                <div>
                  <span className="text-stone-400">Doctor:</span>{' '}
                  <strong className="text-stone-800">{record.veterinarian}</strong>
                </div>

                {record.medications && (
                  <div className="flex items-center gap-1.5">
                    <Pill className="w-3.5 h-3.5 text-stone-400" />
                    <span className="text-stone-400">Prescription:</span>{' '}
                    <span className="text-stone-800 font-medium">{record.medications} ({record.dosage || 'Standard dose'})</span>
                  </div>
                )}

                {record.nextDueDate && (
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-amber-600" />
                    <span className="text-stone-400">Next Booster Due:</span>{' '}
                    <span className="font-mono-data font-semibold text-amber-900">{record.nextDueDate}</span>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      <AddHealthModal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        preselectedCow={preselectedCow}
      />
    </div>
  );
};
