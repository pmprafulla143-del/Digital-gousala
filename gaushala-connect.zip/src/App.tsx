/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GaushalaProvider, useGaushala } from './context/GaushalaContext';
import { Navbar } from './components/Navbar';
import { Storefront } from './components/store/Storefront';
import { CowDirectory } from './components/cows/CowDirectory';
import { HealthRecords } from './components/health/HealthRecords';
import { MilkYieldTracker } from './components/milk/MilkYieldTracker';
import { InventoryManagement } from './components/inventory/InventoryManagement';
import { OrderManagement } from './components/orders/OrderManagement';
import { CartDrawer } from './components/store/CartDrawer';
import { Cow } from './types';
import { Sparkles, Heart, ShieldCheck, RefreshCw } from 'lucide-react';

const MainContent: React.FC = () => {
  const { activeTab, setActiveTab, resetAllData } = useGaushala();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedCowForAction, setSelectedCowForAction] = useState<Cow | null>(null);

  const handleLogYieldForCow = (cow: Cow) => {
    setSelectedCowForAction(cow);
    setActiveTab('yields');
  };

  const handleLogHealthForCow = (cow: Cow) => {
    setSelectedCowForAction(cow);
    setActiveTab('health');
  };

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col text-stone-900">
      {/* Top Navigation */}
      <Navbar onOpenCart={() => setIsCartOpen(true)} />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {activeTab === 'store' && <Storefront />}
        {activeTab === 'cows' && (
          <CowDirectory
            onLogYieldForCow={handleLogYieldForCow}
            onLogHealthForCow={handleLogHealthForCow}
          />
        )}
        {activeTab === 'health' && (
          <HealthRecords preselectedCow={selectedCowForAction} />
        )}
        {activeTab === 'yields' && (
          <MilkYieldTracker
            onGoToInventory={() => setActiveTab('inventory')}
            preselectedCow={selectedCowForAction}
          />
        )}
        {activeTab === 'inventory' && <InventoryManagement />}
        {activeTab === 'orders' && <OrderManagement />}
      </main>

      {/* Cart & Checkout Slide-Over */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onGoToOrders={() => setActiveTab('orders')}
      />

      {/* Footer */}
      <footer className="mt-auto border-t border-stone-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-1 text-center md:text-left">
              <span className="text-base font-bold font-serif-brand text-amber-900 block">
                Surabhi Vedic Gaushala & Dairy
              </span>
              <p className="text-xs text-stone-500 max-w-md">
                Dedicated to the preservation of indigenous Bos indicus cows (Gir, Sahiwal, Tharparkar). 100% of proceeds fund lifelong shelter, herbal pasture, and medical rehabilitation.
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-stone-600">
              <button
                onClick={() => setActiveTab('store')}
                className="hover:text-stone-900 transition-colors cursor-pointer"
              >
                Storefront
              </button>
              <button
                onClick={() => setActiveTab('cows')}
                className="hover:text-stone-900 transition-colors cursor-pointer"
              >
                Cow Registry
              </button>
              <button
                onClick={() => setActiveTab('yields')}
                className="hover:text-stone-900 transition-colors cursor-pointer"
              >
                Dairy Yields
              </button>
              <button
                onClick={() => setActiveTab('inventory')}
                className="hover:text-stone-900 transition-colors cursor-pointer"
              >
                Inventory ERP
              </button>
              <button
                onClick={resetAllData}
                className="inline-flex items-center gap-1.5 text-stone-400 hover:text-stone-700 transition-colors cursor-pointer text-xs"
                title="Reset local storage to original demonstration dataset"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset Demo Data</span>
              </button>
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-stone-100 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-stone-400">
            <div>© {new Date().getFullYear()} Surabhi Vedic Gaushala Trust. Registered Non-Profit Ahimsa Sanctuary.</div>
            <div className="font-mono-data text-stone-400">FSSAI Lic. #11524022000148 · Ahimsa Certified</div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <GaushalaProvider>
      <MainContent />
    </GaushalaProvider>
  );
}
