import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Cow, 
  HealthRecord, 
  MilkYield, 
  Product, 
  RawMaterial, 
  ManufacturingBatch, 
  InventoryAuditLog, 
  Order, 
  OrderItem,
  MilkSubscription, 
  CowAdoption 
} from '../types';
import {
  INITIAL_COWS,
  INITIAL_HEALTH_RECORDS,
  INITIAL_MILK_YIELDS,
  INITIAL_PRODUCTS,
  INITIAL_RAW_MATERIALS,
  INITIAL_BATCHES,
  INITIAL_AUDIT_LOGS,
  INITIAL_ORDERS,
  INITIAL_SUBSCRIPTIONS,
  INITIAL_ADOPTIONS
} from '../data/initialData';

export type ActiveTab = 'store' | 'cows' | 'health' | 'yields' | 'inventory' | 'orders';

export interface CartItem {
  product: Product;
  quantity: number;
}

interface GaushalaContextType {
  // Navigation & View
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  selectedCowIdForDetails: string | null;
  setSelectedCowIdForDetails: (id: string | null) => void;

  // Cows
  cows: Cow[];
  addCow: (cow: Omit<Cow, 'id'>) => Cow;
  updateCow: (id: string, updates: Partial<Cow>) => void;

  // Health
  healthRecords: HealthRecord[];
  addHealthRecord: (record: Omit<HealthRecord, 'id'>) => HealthRecord;
  updateHealthRecord: (id: string, updates: Partial<HealthRecord>) => void;

  // Milk Yields
  milkYields: MilkYield[];
  addMilkYield: (yieldData: Omit<MilkYield, 'id'>) => MilkYield;
  deleteMilkYield: (id: string) => void;

  // Products & Inventory
  products: Product[];
  rawMaterials: RawMaterial[];
  batches: ManufacturingBatch[];
  auditLogs: InventoryAuditLog[];
  createManufacturingBatch: (data: {
    sourceMilkLiters: number;
    targetProductId: string;
    producedUnits: number;
    yieldRatio: string;
    operatorName: string;
    expiryDate: string;
  }) => ManufacturingBatch | { error: string };
  restockRawMaterial: (materialId: string, quantityToAdd: number) => void;
  updateProductStock: (productId: string, newQty: number, reason: string) => void;

  // E-commerce Cart & Orders
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  updateCartQty: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  orders: Order[];
  placeOrder: (data: {
    customerName: string;
    customerPhone: string;
    customerEmail: string;
    deliveryAddress: string;
    city: string;
    pinCode: string;
    paymentMethod: 'UPI' | 'Card' | 'NetBanking' | 'Cash on Delivery';
    donationAmount: number;
  }) => { success: boolean; order?: Order; error?: string };
  updateOrderStatus: (orderId: string, newStatus: Order['orderStatus']) => void;

  // Subscriptions & Cow Adoptions
  subscriptions: MilkSubscription[];
  addSubscription: (sub: Omit<MilkSubscription, 'id'>) => MilkSubscription;
  toggleSubscriptionStatus: (id: string) => void;
  adoptions: CowAdoption[];
  adoptCow: (data: {
    cowId: string;
    donorName: string;
    donorEmail: string;
    donorPhone: string;
    durationMonths: number;
    monthlyAmount: number;
    message?: string;
  }) => CowAdoption;

  // Utility
  rawMilkAvailableLiters: number;
  resetAllData: () => void;
}

const GaushalaContext = createContext<GaushalaContextType | undefined>(undefined);

export const GaushalaProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('store');
  const [selectedCowIdForDetails, setSelectedCowIdForDetails] = useState<string | null>(null);

  // Initialize state with localStorage fallbacks
  const [cows, setCows] = useState<Cow[]>(() => {
    const saved = localStorage.getItem('surabhi_cows');
    return saved ? JSON.parse(saved) : INITIAL_COWS;
  });

  const [healthRecords, setHealthRecords] = useState<HealthRecord[]>(() => {
    const saved = localStorage.getItem('surabhi_health');
    return saved ? JSON.parse(saved) : INITIAL_HEALTH_RECORDS;
  });

  const [milkYields, setMilkYields] = useState<MilkYield[]>(() => {
    const saved = localStorage.getItem('surabhi_yields');
    return saved ? JSON.parse(saved) : INITIAL_MILK_YIELDS;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('surabhi_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [rawMaterials, setRawMaterials] = useState<RawMaterial[]>(() => {
    const saved = localStorage.getItem('surabhi_raw_materials');
    return saved ? JSON.parse(saved) : INITIAL_RAW_MATERIALS;
  });

  const [batches, setBatches] = useState<ManufacturingBatch[]>(() => {
    const saved = localStorage.getItem('surabhi_batches');
    return saved ? JSON.parse(saved) : INITIAL_BATCHES;
  });

  const [auditLogs, setAuditLogs] = useState<InventoryAuditLog[]>(() => {
    const saved = localStorage.getItem('surabhi_audit_logs');
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('surabhi_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('surabhi_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [subscriptions, setSubscriptions] = useState<MilkSubscription[]>(() => {
    const saved = localStorage.getItem('surabhi_subscriptions');
    return saved ? JSON.parse(saved) : INITIAL_SUBSCRIPTIONS;
  });

  const [adoptions, setAdoptions] = useState<CowAdoption[]>(() => {
    const saved = localStorage.getItem('surabhi_adoptions');
    return saved ? JSON.parse(saved) : INITIAL_ADOPTIONS;
  });

  // Sync to localStorage
  useEffect(() => { localStorage.setItem('surabhi_cows', JSON.stringify(cows)); }, [cows]);
  useEffect(() => { localStorage.setItem('surabhi_health', JSON.stringify(healthRecords)); }, [healthRecords]);
  useEffect(() => { localStorage.setItem('surabhi_yields', JSON.stringify(milkYields)); }, [milkYields]);
  useEffect(() => { localStorage.setItem('surabhi_products', JSON.stringify(products)); }, [products]);
  useEffect(() => { localStorage.setItem('surabhi_raw_materials', JSON.stringify(rawMaterials)); }, [rawMaterials]);
  useEffect(() => { localStorage.setItem('surabhi_batches', JSON.stringify(batches)); }, [batches]);
  useEffect(() => { localStorage.setItem('surabhi_audit_logs', JSON.stringify(auditLogs)); }, [auditLogs]);
  useEffect(() => { localStorage.setItem('surabhi_cart', JSON.stringify(cart)); }, [cart]);
  useEffect(() => { localStorage.setItem('surabhi_orders', JSON.stringify(orders)); }, [orders]);
  useEffect(() => { localStorage.setItem('surabhi_subscriptions', JSON.stringify(subscriptions)); }, [subscriptions]);
  useEffect(() => { localStorage.setItem('surabhi_adoptions', JSON.stringify(adoptions)); }, [adoptions]);

  // Compute total raw milk recorded today that hasn't been allocated
  // Or approximate current available raw milk bulk tank
  const todayDateStr = new Date().toISOString().split('T')[0];
  const todayMilkTotal = milkYields
    .filter(y => y.date === todayDateStr || y.date === '2026-10-26')
    .reduce((sum, y) => sum + y.yieldLiters, 0);

  // Bulk milk in tank = today's yield + reserve buffer (e.g. 50L) minus processed
  const rawMilkAvailableLiters = Math.max(12, Math.round(todayMilkTotal + 40));

  // Cow handlers
  const addCow = (cowData: Omit<Cow, 'id'>): Cow => {
    const newCow: Cow = {
      ...cowData,
      id: `cow-${Date.now()}`
    };
    setCows(prev => [newCow, ...prev]);
    return newCow;
  };

  const updateCow = (id: string, updates: Partial<Cow>) => {
    setCows(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  // Health handlers
  const addHealthRecord = (recordData: Omit<HealthRecord, 'id'>): HealthRecord => {
    const newRecord: HealthRecord = {
      ...recordData,
      id: `health-${Date.now()}`
    };
    setHealthRecords(prev => [newRecord, ...prev]);
    return newRecord;
  };

  const updateHealthRecord = (id: string, updates: Partial<HealthRecord>) => {
    setHealthRecords(prev => prev.map(r => r.id === id ? { ...r, ...updates } : r));
  };

  // Milk yield handlers
  const addMilkYield = (yieldData: Omit<MilkYield, 'id'>): MilkYield => {
    const newYield: MilkYield = {
      ...yieldData,
      id: `yield-${Date.now()}`
    };
    setMilkYields(prev => [newYield, ...prev]);

    // Also update cow's average yield
    const cowYields = [newYield, ...milkYields.filter(y => y.cowId === yieldData.cowId)];
    const avg = cowYields.slice(0, 10).reduce((acc, y) => acc + y.yieldLiters, 0) / Math.min(cowYields.length, 10);
    updateCow(yieldData.cowId, { dailyMilkAverageLiters: Number(avg.toFixed(1)) });

    return newYield;
  };

  const deleteMilkYield = (id: string) => {
    setMilkYields(prev => prev.filter(y => y.id !== id));
  };

  // Manufacturing Batch (Converting Raw Milk into Finished Goods like Ghee/Paneer)
  const createManufacturingBatch = (data: {
    sourceMilkLiters: number;
    targetProductId: string;
    producedUnits: number;
    yieldRatio: string;
    operatorName: string;
    expiryDate: string;
  }): ManufacturingBatch | { error: string } => {
    const targetProduct = products.find(p => p.id === data.targetProductId);
    if (!targetProduct) {
      return { error: 'Target product not found.' };
    }

    const batchNumber = `BAT-${Date.now().toString().slice(-6)}`;
    const newBatch: ManufacturingBatch = {
      id: `batch-${Date.now()}`,
      batchNumber,
      date: new Date().toISOString().split('T')[0],
      sourceMilkLiters: data.sourceMilkLiters,
      targetProductId: data.targetProductId,
      targetProductName: targetProduct.name,
      producedUnits: data.producedUnits,
      yieldRatio: data.yieldRatio,
      operatorName: data.operatorName,
      status: 'Quality Passed',
      expiryDate: data.expiryDate,
    };

    // 1. Update Product stock (+ produced units)
    const newStock = targetProduct.inStockQty + data.producedUnits;
    setProducts(prev => prev.map(p => p.id === targetProduct.id ? { ...p, inStockQty: newStock } : p));

    // 2. Add to Batches list
    setBatches(prev => [newBatch, ...prev]);

    // 3. Create Audit Log
    const auditLog: InventoryAuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      productId: targetProduct.id,
      productName: targetProduct.name,
      changeType: 'Production Batch',
      quantityChange: data.producedUnits,
      resultingStock: newStock,
      referenceId: batchNumber,
      notes: `Manufactured ${data.producedUnits} units from ${data.sourceMilkLiters}L fresh raw milk (${data.yieldRatio}).`,
    };
    setAuditLogs(prev => [auditLog, ...prev]);

    return newBatch;
  };

  // Stock management
  const updateProductStock = (productId: string, newQty: number, reason: string) => {
    setProducts(prev => {
      const prod = prev.find(p => p.id === productId);
      if (!prod) return prev;
      const change = newQty - prod.inStockQty;
      
      const auditLog: InventoryAuditLog = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
        productId: prod.id,
        productName: prod.name,
        changeType: 'Manual Adjustment',
        quantityChange: change,
        resultingStock: newQty,
        referenceId: `ADJ-${Date.now().toString().slice(-4)}`,
        notes: reason || 'Manual stock count update',
      };
      setAuditLogs(l => [auditLog, ...l]);

      return prev.map(p => p.id === productId ? { ...p, inStockQty: newQty } : p);
    });
  };

  const restockRawMaterial = (materialId: string, quantityToAdd: number) => {
    setRawMaterials(prev => prev.map(m => {
      if (m.id === materialId) {
        return {
          ...m,
          currentStock: m.currentStock + quantityToAdd,
          lastRestocked: new Date().toISOString().split('T')[0]
        };
      }
      return m;
    }));
  };

  // Cart operations
  const addToCart = (product: Product, quantity: number = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  const updateCartQty = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item =>
      item.product.id === productId ? { ...item, quantity } : item
    ));
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Place order with automated inventory deduction
  const placeOrder = (data: {
    customerName: string;
    customerPhone: string;
    customerEmail: string;
    deliveryAddress: string;
    city: string;
    pinCode: string;
    paymentMethod: 'UPI' | 'Card' | 'NetBanking' | 'Cash on Delivery';
    donationAmount: number;
  }): { success: boolean; order?: Order; error?: string } => {
    if (cart.length === 0) {
      return { success: false, error: 'Your cart is empty.' };
    }

    // 1. Check stock availability for physical goods
    for (const item of cart) {
      const product = products.find(p => p.id === item.product.id);
      if (product && product.category !== 'Gau Grass & Seva' && product.inStockQty < item.quantity) {
        return { 
          success: false, 
          error: `Insufficient stock for "${product.name}". Only ${product.inStockQty} units available.` 
        };
      }
    }

    const orderNumber = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
    const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    const deliveryFee = subtotal > 1000 ? 0 : 60;
    const totalAmount = subtotal + deliveryFee + data.donationAmount;

    const orderItems: OrderItem[] = cart.map(item => ({
      productId: item.product.id,
      productName: item.product.name,
      price: item.product.price,
      quantity: item.quantity,
      unit: item.product.unit,
      image: item.product.image
    }));

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      customerName: data.customerName,
      customerPhone: data.customerPhone,
      customerEmail: data.customerEmail,
      deliveryAddress: data.deliveryAddress,
      city: data.city,
      pinCode: data.pinCode,
      items: orderItems,
      subtotal,
      deliveryFee,
      donationAmount: data.donationAmount,
      totalAmount,
      paymentMethod: data.paymentMethod,
      paymentStatus: data.paymentMethod === 'Cash on Delivery' ? 'Cash on Delivery' : 'Paid',
      orderStatus: 'Placed',
      orderDate: new Date().toISOString().replace('T', ' ').substring(0, 16),
      estimatedDelivery: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      trackingNotes: 'Order received. Fresh packaging scheduled.',
    };

    // 2. Automated Inventory Deduction for each item in the order
    setProducts(prevProducts => {
      return prevProducts.map(prod => {
        const orderedItem = cart.find(c => c.product.id === prod.id);
        if (orderedItem && prod.category !== 'Gau Grass & Seva') {
          const updatedStock = Math.max(0, prod.inStockQty - orderedItem.quantity);
          
          // Create Audit Log for this deduction
          const deductionLog: InventoryAuditLog = {
            id: `log-${Date.now()}-${prod.id}`,
            timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
            productId: prod.id,
            productName: prod.name,
            changeType: 'Order Deduction',
            quantityChange: -orderedItem.quantity,
            resultingStock: updatedStock,
            referenceId: orderNumber,
            notes: `Automated inventory deduction on customer checkout for Order #${orderNumber}.`,
          };
          setAuditLogs(logs => [deductionLog, ...logs]);

          return {
            ...prod,
            inStockQty: updatedStock,
          };
        }
        return prod;
      });
    });

    // 3. Save order and clear cart
    setOrders(prev => [newOrder, ...prev]);
    clearCart();

    return { success: true, order: newOrder };
  };

  const updateOrderStatus = (orderId: string, newStatus: Order['orderStatus']) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, orderStatus: newStatus } : o));
  };

  // Milk Subscriptions
  const addSubscription = (subData: Omit<MilkSubscription, 'id'>): MilkSubscription => {
    const newSub: MilkSubscription = {
      ...subData,
      id: `sub-${Date.now()}`
    };
    setSubscriptions(prev => [newSub, ...prev]);
    return newSub;
  };

  const toggleSubscriptionStatus = (id: string) => {
    setSubscriptions(prev => prev.map(s => {
      if (s.id === id) {
        return {
          ...s,
          status: s.status === 'Active' ? 'Paused' : 'Active'
        };
      }
      return s;
    }));
  };

  // Cow Adoption & Gau Seva
  const adoptCow = (data: {
    cowId: string;
    donorName: string;
    donorEmail: string;
    donorPhone: string;
    durationMonths: number;
    monthlyAmount: number;
    message?: string;
  }): CowAdoption => {
    const cow = cows.find(c => c.id === data.cowId);
    const cowName = cow ? cow.name : 'Vedic Cow';
    const cowTag = cow ? cow.tagNumber : 'GIR';
    const cowBreed = cow ? cow.breed : 'Gir';

    const certificateId = `GAU-SEVA-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
    const newAdoption: CowAdoption = {
      id: `adopt-${Date.now()}`,
      cowId: data.cowId,
      cowName,
      cowTag,
      cowBreed,
      donorName: data.donorName,
      donorEmail: data.donorEmail,
      donorPhone: data.donorPhone,
      durationMonths: data.durationMonths,
      monthlyAmount: data.monthlyAmount,
      totalDonation: data.durationMonths * data.monthlyAmount,
      startDate: new Date().toISOString().split('T')[0],
      certificateId,
      message: data.message,
    };

    // Mark cow as adopted
    updateCow(data.cowId, {
      isAdopted: true,
      sponsorName: data.donorName
    });

    setAdoptions(prev => [newAdoption, ...prev]);
    return newAdoption;
  };

  const resetAllData = () => {
    localStorage.removeItem('surabhi_cows');
    localStorage.removeItem('surabhi_health');
    localStorage.removeItem('surabhi_yields');
    localStorage.removeItem('surabhi_products');
    localStorage.removeItem('surabhi_raw_materials');
    localStorage.removeItem('surabhi_batches');
    localStorage.removeItem('surabhi_audit_logs');
    localStorage.removeItem('surabhi_cart');
    localStorage.removeItem('surabhi_orders');
    localStorage.removeItem('surabhi_subscriptions');
    localStorage.removeItem('surabhi_adoptions');

    setCows(INITIAL_COWS);
    setHealthRecords(INITIAL_HEALTH_RECORDS);
    setMilkYields(INITIAL_MILK_YIELDS);
    setProducts(INITIAL_PRODUCTS);
    setRawMaterials(INITIAL_RAW_MATERIALS);
    setBatches(INITIAL_BATCHES);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setCart([]);
    setOrders(INITIAL_ORDERS);
    setSubscriptions(INITIAL_SUBSCRIPTIONS);
    setAdoptions(INITIAL_ADOPTIONS);
  };

  return (
    <GaushalaContext.Provider
      value={{
        activeTab,
        setActiveTab,
        selectedCowIdForDetails,
        setSelectedCowIdForDetails,
        cows,
        addCow,
        updateCow,
        healthRecords,
        addHealthRecord,
        updateHealthRecord,
        milkYields,
        addMilkYield,
        deleteMilkYield,
        products,
        rawMaterials,
        batches,
        auditLogs,
        createManufacturingBatch,
        restockRawMaterial,
        updateProductStock,
        cart,
        addToCart,
        updateCartQty,
        removeFromCart,
        clearCart,
        orders,
        placeOrder,
        updateOrderStatus,
        subscriptions,
        addSubscription,
        toggleSubscriptionStatus,
        adoptions,
        adoptCow,
        rawMilkAvailableLiters,
        resetAllData,
      }}
    >
      {children}
    </GaushalaContext.Provider>
  );
};

export const useGaushala = () => {
  const context = useContext(GaushalaContext);
  if (!context) {
    throw new Error('useGaushala must be used within a GaushalaProvider');
  }
  return context;
};
